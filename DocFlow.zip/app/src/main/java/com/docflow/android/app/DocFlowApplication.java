package com.docflow.android.app;

import android.app.Application;
import com.docflow.android.app.data.DocRepository;
import com.docflow.android.app.util.ThemeManager;
import java.io.File;

public class DocFlowApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        // 1. Initialize and apply user theme
        ThemeManager.applyTheme(this);

        // 2. Initialize repository and ensure local directories exist
        DocRepository.getInstance(this);

        File docDir = new File(getFilesDir(), "documents");
        if (!docDir.exists()) docDir.mkdirs();

        File thumbDir = new File(getFilesDir(), "thumbnails");
        if (!thumbDir.exists()) thumbDir.mkdirs();

        File cacheScanDir = new File(getCacheDir(), "scans");
        if (!cacheScanDir.exists()) cacheScanDir.mkdirs();
    }
}
