package com.docflow.android.app.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.docflow.android.app.R;
import com.docflow.android.app.engine.ImageEngine;
import com.docflow.android.app.model.DocModel;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class DocumentAdapter extends RecyclerView.Adapter<DocumentAdapter.DocViewHolder> {

    public interface OnDocActionListener {
        void onDocClick(DocModel doc);
        void onDocMore(DocModel doc, View anchor);
    }

    private final Context context;
    private List<DocModel> docList = new ArrayList<>();
    private final OnDocActionListener listener;

    public DocumentAdapter(Context context, OnDocActionListener listener) {
        this.context = context;
        this.listener = listener;
    }

    public void setDocuments(List<DocModel> docs) {
        this.docList = (docs != null) ? docs : new ArrayList<>();
        notifyDataSetChanged();
    }

    @Override
    public DocViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_document_grid, parent, false);
        return new DocViewHolder(view);
    }

    @Override
    public void onBindViewHolder(DocViewHolder holder, int position) {
        DocModel doc = docList.get(position);
        holder.textTitle.setText(doc.getTitle());
        holder.textInfo.setText(doc.getFormattedDate() + " • " + doc.getFormattedSize());

        int pages = doc.getPageCount();
        holder.textBadge.setText(pages + (pages == 1 ? " Page" : " Pages"));

        // Load thumbnail safely
        if (doc.getThumbnailPath() != null && new File(doc.getThumbnailPath()).exists()) {
            Bitmap thumb = ImageEngine.decodeSampledBitmapFromFile(doc.getThumbnailPath(), 300, 200);
            if (thumb != null) {
                holder.imageThumb.setImageBitmap(thumb);
            } else {
                holder.imageThumb.setImageResource(R.drawable.ic_pdf);
            }
        } else {
            holder.imageThumb.setImageResource(R.drawable.ic_pdf);
        }

        holder.cardRoot.setOnClickListener(v -> {
            if (listener != null) listener.onDocClick(doc);
        });

        holder.btnMore.setOnClickListener(v -> {
            if (listener != null) listener.onDocMore(doc, v);
        });
    }

    @Override
    public int getItemCount() {
        return docList.size();
    }

    public static class DocViewHolder extends RecyclerView.ViewHolder {
        CardView cardRoot;
        ImageView imageThumb;
        TextView textTitle;
        TextView textInfo;
        TextView textBadge;
        ImageButton btnMore;

        public DocViewHolder(View itemView) {
            super(itemView);
            cardRoot = itemView.findViewById(R.id.card_document);
            imageThumb = itemView.findViewById(R.id.doc_thumbnail);
            textTitle = itemView.findViewById(R.id.doc_title);
            textInfo = itemView.findViewById(R.id.doc_info);
            textBadge = itemView.findViewById(R.id.doc_page_count_badge);
            btnMore = itemView.findViewById(R.id.btn_doc_more);
        }
    }
}
