package com.docflow.android.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.docflow.android.app.data.DocRepository;
import com.docflow.android.app.engine.PdfEngine;
import com.docflow.android.app.model.DocModel;
import com.docflow.android.app.util.InsetsHelper;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PdfToolsActivity extends AppCompatActivity {

    private static final int REQ_PICK_FOR_MERGE = 201;
    private static final int REQ_PICK_FOR_SPLIT = 202;
    private static final int REQ_PICK_FOR_EXTRACT = 203;
    private static final int REQ_PICK_FOR_IMAGES = 204;
    private static final int REQ_PICK_FOR_COMPRESS = 205;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pdf_tools);

        View root = findViewById(R.id.tools_root);
        InsetsHelper.setupEdgeToEdge(this, root);

        ImageButton btnBack = findViewById(R.id.btn_tools_back);
        btnBack.setOnClickListener(v -> finish());

        findViewById(R.id.card_tool_merge).setOnClickListener(v -> pickPdfsForMerge());
        findViewById(R.id.card_tool_split).setOnClickListener(v -> pickPdf(REQ_PICK_FOR_SPLIT));
        findViewById(R.id.card_tool_compress).setOnClickListener(v -> pickPdf(REQ_PICK_FOR_COMPRESS));
        findViewById(R.id.card_tool_export_img).setOnClickListener(v -> pickPdf(REQ_PICK_FOR_IMAGES));
    }

    private void pickPdfsForMerge() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(intent, REQ_PICK_FOR_MERGE);
    }

    private void pickPdf(int requestCode) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        startActivityForResult(intent, requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;

        if (requestCode == REQ_PICK_FOR_MERGE) {
            handleMerge(data);
        } else if (requestCode == REQ_PICK_FOR_SPLIT) {
            handleSplit(data.getData());
        } else if (requestCode == REQ_PICK_FOR_COMPRESS) {
            handleCompress(data.getData());
        } else if (requestCode == REQ_PICK_FOR_IMAGES) {
            handleExportImages(data.getData());
        }
    }

    private void handleMerge(Intent data) {
        List<Uri> uris = new ArrayList<>();
        if (data.getClipData() != null) {
            for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                uris.add(data.getClipData().getItemAt(i).getUri());
            }
        } else if (data.getData() != null) {
            uris.add(data.getData());
        }

        if (uris.size() < 2) {
            Toast.makeText(this, "Please select at least 2 PDF files to merge.", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Merging " + uris.size() + " PDFs…", Toast.LENGTH_SHORT).show();

        executor.execute(() -> {
            List<File> tempFiles = new ArrayList<>();
            File cacheDir = new File(getCacheDir(), "merge_temp");
            if (!cacheDir.exists()) cacheDir.mkdirs();

            for (int i = 0; i < uris.size(); i++) {
                File temp = copyUriToTempFile(uris.get(i), cacheDir, "merge_" + i + ".pdf");
                if (temp != null) tempFiles.add(temp);
            }

            File docsDir = new File(getFilesDir(), "documents");
            if (!docsDir.exists()) docsDir.mkdirs();
            String name = "Merged_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date()) + ".pdf";
            File mergedOutput = new File(docsDir, name);

            boolean ok = PdfEngine.mergePdfs(tempFiles, mergedOutput);

            if (ok) {
                String docId = String.valueOf(System.currentTimeMillis());
                File thumb = PdfEngine.generatePdfThumbnail(this, mergedOutput, docId);
                DocModel doc = new DocModel();
                doc.setId(docId);
                doc.setTitle(name.replace(".pdf", ""));
                doc.setPdfPath(mergedOutput.getAbsolutePath());
                if (thumb != null) doc.setThumbnailPath(thumb.getAbsolutePath());
                doc.setDateModified(System.currentTimeMillis());
                doc.setPageCount(PdfEngine.getPdfPageCount(mergedOutput));
                doc.setFileSizeBytes(mergedOutput.length());
                doc.setTag("imported");

                DocRepository.getInstance(this).addDocument(doc);

                mainHandler.post(() -> {
                    Toast.makeText(this, "PDFs merged successfully!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(this, PdfViewerActivity.class);
                    intent.putExtra("doc_model", doc);
                    startActivity(intent);
                });
            } else {
                mainHandler.post(() -> Toast.makeText(this, R.string.msg_operation_failed, Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void handleSplit(Uri pdfUri) {
        if (pdfUri == null) return;
        Toast.makeText(this, "Splitting PDF pages…", Toast.LENGTH_SHORT).show();

        executor.execute(() -> {
            File cacheDir = new File(getCacheDir(), "split_temp");
            if (!cacheDir.exists()) cacheDir.mkdirs();
            File srcFile = copyUriToTempFile(pdfUri, cacheDir, "split_source.pdf");
            if (srcFile == null) return;

            File docsDir = new File(getFilesDir(), "documents");
            List<File> generated = PdfEngine.splitPdf(srcFile, docsDir);

            for (File singlePage : generated) {
                String docId = String.valueOf(System.currentTimeMillis() + (long)(Math.random() * 1000));
                File thumb = PdfEngine.generatePdfThumbnail(this, singlePage, docId);
                DocModel doc = new DocModel();
                doc.setId(docId);
                doc.setTitle(singlePage.getName().replace(".pdf", ""));
                doc.setPdfPath(singlePage.getAbsolutePath());
                if (thumb != null) doc.setThumbnailPath(thumb.getAbsolutePath());
                doc.setDateModified(System.currentTimeMillis());
                doc.setPageCount(1);
                doc.setFileSizeBytes(singlePage.length());
                doc.setTag("imported");
                DocRepository.getInstance(this).addDocument(doc);
            }

            mainHandler.post(() -> {
                Toast.makeText(this, "Split into " + generated.size() + " separate documents!", Toast.LENGTH_LONG).show();
                finish();
            });
        });
    }

    private void handleCompress(Uri pdfUri) {
        if (pdfUri == null) return;

        String[] options = {"Low Compression (Best Quality)", "Balanced (Recommended)", "Maximum Compression (Smallest Size)"};
        new AlertDialog.Builder(this)
            .setTitle(R.string.tool_compress_title)
            .setItems(options, (dialog, which) -> {
                int quality = (which == 0) ? 80 : (which == 1 ? 60 : 40);
                executeCompression(pdfUri, quality);
            })
            .show();
    }

    private void executeCompression(Uri pdfUri, int quality) {
        Toast.makeText(this, "Compressing PDF…", Toast.LENGTH_SHORT).show();

        executor.execute(() -> {
            File cacheDir = new File(getCacheDir(), "compress_temp");
            if (!cacheDir.exists()) cacheDir.mkdirs();
            File srcFile = copyUriToTempFile(pdfUri, cacheDir, "compress_source.pdf");
            if (srcFile == null) return;

            long origSize = srcFile.length();

            File docsDir = new File(getFilesDir(), "documents");
            String outName = "Compressed_" + srcFile.getName();
            File outFile = new File(docsDir, outName);

            boolean ok = PdfEngine.compressPdf(srcFile, outFile, quality);
            long newSize = outFile.length();

            if (ok) {
                String docId = String.valueOf(System.currentTimeMillis());
                File thumb = PdfEngine.generatePdfThumbnail(this, outFile, docId);
                DocModel doc = new DocModel();
                doc.setId(docId);
                doc.setTitle(outName.replace(".pdf", ""));
                doc.setPdfPath(outFile.getAbsolutePath());
                if (thumb != null) doc.setThumbnailPath(thumb.getAbsolutePath());
                doc.setDateModified(System.currentTimeMillis());
                doc.setPageCount(PdfEngine.getPdfPageCount(outFile));
                doc.setFileSizeBytes(newSize);
                doc.setTag("imported");
                DocRepository.getInstance(this).addDocument(doc);

                float savedPercent = Math.max(0, (1.0f - (float) newSize / origSize) * 100);

                mainHandler.post(() -> {
                    String msg = String.format(Locale.getDefault(), "Compressed! Reduced by %.1f%% (%s → %s)",
                        savedPercent, formatBytes(origSize), formatBytes(newSize));
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show();

                    Intent intent = new Intent(this, PdfViewerActivity.class);
                    intent.putExtra("doc_model", doc);
                    startActivity(intent);
                });
            } else {
                mainHandler.post(() -> Toast.makeText(this, R.string.msg_operation_failed, Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void handleExportImages(Uri pdfUri) {
        if (pdfUri == null) return;
        Toast.makeText(this, "Exporting pages to gallery images…", Toast.LENGTH_SHORT).show();

        executor.execute(() -> {
            File cacheDir = new File(getCacheDir(), "export_img_temp");
            if (!cacheDir.exists()) cacheDir.mkdirs();
            File srcFile = copyUriToTempFile(pdfUri, cacheDir, "img_source.pdf");
            if (srcFile == null) return;

            File exportDir = new File(getExternalFilesDir(null), "ExportedImages");
            List<File> images = PdfEngine.exportPagesToImages(srcFile, exportDir, "JPG");

            mainHandler.post(() -> {
                Toast.makeText(this, "Exported " + images.size() + " pages to " + exportDir.getName(), Toast.LENGTH_LONG).show();
            });
        });
    }

    private File copyUriToTempFile(Uri uri, File targetDir, String filename) {
        try {
            File file = new File(targetDir, filename);
            try (InputStream is = getContentResolver().openInputStream(uri);
                 FileOutputStream fos = new FileOutputStream(file)) {
                byte[] buffer = new byte[8192];
                int len;
                while ((len = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, len);
                }
                fos.flush();
            }
            return file;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private String formatBytes(long bytes) {
        if (bytes < 1024 * 1024) {
            return String.format(Locale.getDefault(), "%.1f KB", bytes / 1024.0);
        }
        return String.format(Locale.getDefault(), "%.1f MB", bytes / (1024.0 * 1024.0));
    }
}
