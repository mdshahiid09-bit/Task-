package com.docflow.android.app.model;

import org.json.JSONException;
import org.json.JSONObject;
import java.io.File;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DocModel implements Serializable {
    private String id;
    private String title;
    private String pdfPath;
    private String thumbnailPath;
    private long dateModified;
    private int pageCount;
    private long fileSizeBytes;
    private String tag;
    private boolean isFavorite;

    public DocModel() {
        this.id = String.valueOf(System.currentTimeMillis());
        this.dateModified = System.currentTimeMillis();
        this.pageCount = 1;
        this.tag = "scans";
        this.isFavorite = false;
    }

    public DocModel(String id, String title, String pdfPath, String thumbnailPath, long dateModified, int pageCount, long fileSizeBytes, String tag, boolean isFavorite) {
        this.id = id;
        this.title = title;
        this.pdfPath = pdfPath;
        this.thumbnailPath = thumbnailPath;
        this.dateModified = dateModified;
        this.pageCount = pageCount;
        this.fileSizeBytes = fileSizeBytes;
        this.tag = tag;
        this.isFavorite = isFavorite;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getPdfPath() { return pdfPath; }
    public void setPdfPath(String pdfPath) { this.pdfPath = pdfPath; }

    public String getThumbnailPath() { return thumbnailPath; }
    public void setThumbnailPath(String thumbnailPath) { this.thumbnailPath = thumbnailPath; }

    public long getDateModified() { return dateModified; }
    public void setDateModified(long dateModified) { this.dateModified = dateModified; }

    public int getPageCount() { return pageCount; }
    public void setPageCount(int pageCount) { this.pageCount = pageCount; }

    public long getFileSizeBytes() { return fileSizeBytes; }
    public void setFileSizeBytes(long fileSizeBytes) { this.fileSizeBytes = fileSizeBytes; }

    public String getTag() { return tag; }
    public void setTag(String tag) { this.tag = tag; }

    public boolean isFavorite() { return isFavorite; }
    public void setFavorite(boolean favorite) { isFavorite = favorite; }

    public String getFormattedDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("MMM d, yyyy • h:mm a", Locale.getDefault());
        return sdf.format(new Date(dateModified));
    }

    public String getFormattedSize() {
        if (fileSizeBytes <= 0 && pdfPath != null) {
            File f = new File(pdfPath);
            if (f.exists()) fileSizeBytes = f.length();
        }
        if (fileSizeBytes <= 0) return "0 KB";
        if (fileSizeBytes < 1024 * 1024) {
            return String.format(Locale.getDefault(), "%.1f KB", fileSizeBytes / 1024.0);
        }
        return String.format(Locale.getDefault(), "%.1f MB", fileSizeBytes / (1024.0 * 1024.0));
    }

    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        try {
            json.put("id", id);
            json.put("title", title);
            json.put("pdfPath", pdfPath);
            json.put("thumbnailPath", thumbnailPath);
            json.put("dateModified", dateModified);
            json.put("pageCount", pageCount);
            json.put("fileSizeBytes", fileSizeBytes);
            json.put("tag", tag);
            json.put("isFavorite", isFavorite);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return json;
    }

    public static DocModel fromJson(JSONObject json) {
        if (json == null) return null;
        DocModel doc = new DocModel();
        doc.setId(json.optString("id", String.valueOf(System.currentTimeMillis())));
        doc.setTitle(json.optString("title", "Untitled Document"));
        doc.setPdfPath(json.optString("pdfPath", ""));
        doc.setThumbnailPath(json.optString("thumbnailPath", ""));
        doc.setDateModified(json.optLong("dateModified", System.currentTimeMillis()));
        doc.setPageCount(json.optInt("pageCount", 1));
        doc.setFileSizeBytes(json.optLong("fileSizeBytes", 0));
        doc.setTag(json.optString("tag", "scans"));
        doc.setFavorite(json.optBoolean("isFavorite", false));
        return doc;
    }
}
