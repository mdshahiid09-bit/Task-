package com.docflow.android.app.util;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import com.docflow.android.app.SplashActivity;

public class BootstrapperView extends FrameLayout {

    public BootstrapperView(Context context) {
        super(context);
        triggerRouting(context);
    }

    public BootstrapperView(Context context, AttributeSet attrs) {
        super(context, attrs);
        triggerRouting(context);
    }

    public BootstrapperView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        triggerRouting(context);
    }

    private void triggerRouting(Context context) {
        post(() -> {
            if (context instanceof Activity) {
                Activity act = (Activity) context;
                if (!act.isFinishing()) {
                    Intent intent = new Intent(act, SplashActivity.class);
                    act.startActivity(intent);
                    act.finish();
                }
            }
        });
    }
}
