package com.docflow.android.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.docflow.android.app.engine.ImageEngine;
import com.docflow.android.app.util.HapticHelper;
import com.docflow.android.app.util.InsetsHelper;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class CameraScanActivity extends AppCompatActivity implements TextureView.SurfaceTextureListener {

    private static final int REQ_CAMERA_PERM = 101;
    private static final int REQ_GALLERY = 102;

    private TextureView textureView;
    private Camera camera;
    private ImageButton btnFlash;
    private ImageButton btnShutter;
    private ImageButton btnGallery;
    private Button btnDone;
    private ImageButton btnClose;

    private boolean isFlashOn = false;
    private final ArrayList<String> capturedPages = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera_scan);

        View root = findViewById(R.id.camera_root);
        InsetsHelper.setupImmersiveFullscreen(this, root);

        textureView = findViewById(R.id.camera_texture_view);
        btnFlash = findViewById(R.id.btn_flash);
        btnShutter = findViewById(R.id.btn_shutter);
        btnGallery = findViewById(R.id.btn_gallery_import);
        btnDone = findViewById(R.id.btn_done_scan);
        btnClose = findViewById(R.id.btn_camera_close);

        textureView.setSurfaceTextureListener(this);

        btnShutter.setOnClickListener(v -> takePicture());

        btnFlash.setOnClickListener(v -> toggleFlash());

        btnGallery.setOnClickListener(v -> openGalleryPicker());

        btnDone.setOnClickListener(v -> finishAndOpenEditor());

        btnClose.setOnClickListener(v -> finish());

        updatePageCount();

        checkCameraPermission();
    }

    private void checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQ_CAMERA_PERM);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CAMERA_PERM) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startCamera();
            } else {
                Toast.makeText(this, R.string.scanner_permission_required, Toast.LENGTH_LONG).show();
            }
        }
    }

    private void startCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        try {
            if (camera != null) {
                camera.stopPreview();
                camera.release();
            }
            camera = Camera.open();
            camera.setDisplayOrientation(90);

            Camera.Parameters params = camera.getParameters();
            List<String> focusModes = params.getSupportedFocusModes();
            if (focusModes != null && focusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) {
                params.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
            }
            camera.setParameters(params);

            if (textureView.isAvailable()) {
                camera.setPreviewTexture(textureView.getSurfaceTexture());
                camera.startPreview();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void toggleFlash() {
        if (camera == null) return;
        try {
            Camera.Parameters params = camera.getParameters();
            List<String> flashModes = params.getSupportedFlashModes();
            if (flashModes == null) return;

            if (isFlashOn) {
                if (flashModes.contains(Camera.Parameters.FLASH_MODE_OFF)) {
                    params.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
                    camera.setParameters(params);
                    isFlashOn = false;
                    btnFlash.setImageResource(R.drawable.ic_flash_off);
                }
            } else {
                if (flashModes.contains(Camera.Parameters.FLASH_MODE_TORCH)) {
                    params.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
                } else if (flashModes.contains(Camera.Parameters.FLASH_MODE_ON)) {
                    params.setFlashMode(Camera.Parameters.FLASH_MODE_ON);
                }
                camera.setParameters(params);
                isFlashOn = true;
                btnFlash.setImageResource(R.drawable.ic_flash_on);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void takePicture() {
        if (camera == null) return;
        HapticHelper.performShutter(this);
        btnShutter.setEnabled(false);

        try {
            camera.takePicture(null, null, (data, cam) -> {
                try {
                    Bitmap bmp = BitmapFactory.decodeByteArray(data, 0, data.length);
                    // Rotate 90 degrees for portrait orientation
                    Bitmap portraitBmp = ImageEngine.rotateBitmap(bmp, 90);

                    File scansDir = new File(getCacheDir(), "scans");
                    if (!scansDir.exists()) scansDir.mkdirs();

                    File pageFile = new File(scansDir, "page_" + System.currentTimeMillis() + ".jpg");
                    ImageEngine.saveBitmapToFile(portraitBmp, pageFile, Bitmap.CompressFormat.JPEG, 92);

                    if (portraitBmp != bmp) bmp.recycle();
                    portraitBmp.recycle();

                    capturedPages.add(pageFile.getAbsolutePath());
                    runOnUiThread(() -> {
                        updatePageCount();
                        btnShutter.setEnabled(true);
                        // Resume preview for multi-page scanning
                        try {
                            camera.startPreview();
                        } catch (Exception ignored) {}
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                    runOnUiThread(() -> btnShutter.setEnabled(true));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
            btnShutter.setEnabled(true);
        }
    }

    private void openGalleryPicker() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(Intent.createChooser(intent, "Select Document Images"), REQ_GALLERY);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_GALLERY && resultCode == RESULT_OK && data != null) {
            File scansDir = new File(getCacheDir(), "scans");
            if (!scansDir.exists()) scansDir.mkdirs();

            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                for (int i = 0; i < count; i++) {
                    Uri uri = data.getClipData().getItemAt(i).getUri();
                    saveUriToScanFile(uri, scansDir);
                }
            } else if (data.getData() != null) {
                saveUriToScanFile(data.getData(), scansDir);
            }
            updatePageCount();
        }
    }

    private void saveUriToScanFile(Uri uri, File scansDir) {
        try (InputStream is = getContentResolver().openInputStream(uri)) {
            Bitmap bmp = BitmapFactory.decodeStream(is);
            if (bmp != null) {
                File pageFile = new File(scansDir, "import_" + System.currentTimeMillis() + ".jpg");
                ImageEngine.saveBitmapToFile(bmp, pageFile, Bitmap.CompressFormat.JPEG, 92);
                bmp.recycle();
                capturedPages.add(pageFile.getAbsolutePath());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updatePageCount() {
        int count = capturedPages.size();
        btnDone.setText(getString(R.string.scanner_finish, count));
        btnDone.setEnabled(count > 0);
    }

    private void finishAndOpenEditor() {
        if (capturedPages.isEmpty()) return;
        Intent intent = new Intent(this, DocumentEditorActivity.class);
        intent.putStringArrayListExtra("pages_list", capturedPages);
        startActivity(intent);
        finish();
    }

    @Override
    public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
        startCamera();
    }

    @Override
    public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {}

    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
        if (camera != null) {
            camera.stopPreview();
            camera.release();
            camera = null;
        }
        return true;
    }

    @Override
    public void onSurfaceTextureUpdated(SurfaceTexture surface) {}

    @Override
    protected void onPause() {
        super.onPause();
        if (camera != null) {
            camera.stopPreview();
            camera.release();
            camera = null;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (textureView.isAvailable()) {
            startCamera();
        }
    }
}
