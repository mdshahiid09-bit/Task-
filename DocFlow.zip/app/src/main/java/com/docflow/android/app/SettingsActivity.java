package com.docflow.android.app;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.docflow.android.app.engine.PdfEngine;
import com.docflow.android.app.util.InsetsHelper;
import com.docflow.android.app.util.ThemeManager;

public class SettingsActivity extends AppCompatActivity {

    private static final String PREF_SETTINGS = "docflow_user_settings";
    private static final String KEY_DEFAULT_PAGE_SIZE = "default_page_size";

    private TextView textTheme;
    private TextView textPageSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        View root = findViewById(R.id.settings_root);
        InsetsHelper.setupEdgeToEdge(this, root);

        ImageButton btnBack = findViewById(R.id.btn_settings_back);
        btnBack.setOnClickListener(v -> finish());

        textTheme = findViewById(R.id.text_current_theme);
        textPageSize = findViewById(R.id.text_current_pagesize);

        updateLabels();

        findViewById(R.id.card_setting_theme).setOnClickListener(v -> showThemeDialog());
        findViewById(R.id.card_setting_pagesize).setOnClickListener(v -> showPageSizeDialog());
    }

    private void updateLabels() {
        int theme = ThemeManager.getSavedTheme(this);
        textTheme.setText(ThemeManager.getThemeName(this, theme));

        SharedPreferences prefs = getSharedPreferences(PREF_SETTINGS, MODE_PRIVATE);
        String size = prefs.getString(KEY_DEFAULT_PAGE_SIZE, PdfEngine.PAGE_SIZE_A4);
        textPageSize.setText(size);
    }

    private void showThemeDialog() {
        String[] themes = {"Follow System", "Light", "Dark"};
        int current = ThemeManager.getSavedTheme(this);

        new AlertDialog.Builder(this)
            .setTitle(R.string.settings_theme)
            .setSingleChoiceItems(themes, current, (dialog, which) -> {
                dialog.dismiss();
                ThemeManager.setSavedTheme(this, which);
                updateLabels();
            })
            .show();
    }

    private void showPageSizeDialog() {
        String[] sizes = {PdfEngine.PAGE_SIZE_A4, PdfEngine.PAGE_SIZE_LETTER, PdfEngine.PAGE_SIZE_LEGAL, PdfEngine.PAGE_SIZE_FIT};
        new AlertDialog.Builder(this)
            .setTitle(R.string.settings_default_page_size)
            .setItems(sizes, (dialog, which) -> {
                String chosen = sizes[which];
                getSharedPreferences(PREF_SETTINGS, MODE_PRIVATE)
                    .edit()
                    .putString(KEY_DEFAULT_PAGE_SIZE, chosen)
                    .apply();
                updateLabels();
            })
            .show();
    }
}
