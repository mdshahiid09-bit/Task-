package com.docflow.android.app.data;

import android.content.Context;
import com.docflow.android.app.model.DocModel;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class DocRepository {
    private static DocRepository instance;
    private final Context appContext;
    private final List<DocModel> documentList = new ArrayList<>();
    private final File dataFile;

    public static final int SORT_DATE_DESC = 0;
    public static final int SORT_DATE_ASC = 1;
    public static final int SORT_NAME_ASC = 2;
    public static final int SORT_NAME_DESC = 3;
    public static final int SORT_SIZE_DESC = 4;
    public static final int SORT_SIZE_ASC = 5;

    private DocRepository(Context context) {
        this.appContext = context.getApplicationContext();
        File dir = appContext.getFilesDir();
        this.dataFile = new File(dir, "docflow_library.json");
        loadFromFile();
    }

    public static synchronized DocRepository getInstance(Context context) {
        if (instance == null) {
            instance = new DocRepository(context);
        }
        return instance;
    }

    private synchronized void loadFromFile() {
        documentList.clear();
        if (!dataFile.exists()) return;
        try (FileInputStream fis = new FileInputStream(dataFile)) {
            byte[] buffer = new byte[(int) dataFile.length()];
            fis.read(buffer);
            String jsonStr = new String(buffer, StandardCharsets.UTF_8);
            JSONArray array = new JSONArray(jsonStr);
            for (int i = 0; i < array.length(); i++) {
                DocModel doc = DocModel.fromJson(array.getJSONObject(i));
                if (doc != null) {
                    // Check if PDF file still exists
                    if (doc.getPdfPath() != null && new File(doc.getPdfPath()).exists()) {
                        documentList.add(doc);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private synchronized void saveToFile() {
        try {
            JSONArray array = new JSONArray();
            for (DocModel doc : documentList) {
                array.put(doc.toJson());
            }
            try (FileOutputStream fos = new FileOutputStream(dataFile)) {
                fos.write(array.toString().getBytes(StandardCharsets.UTF_8));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public synchronized List<DocModel> getAllDocuments() {
        return new ArrayList<>(documentList);
    }

    public synchronized DocModel getDocumentById(String id) {
        for (DocModel doc : documentList) {
            if (doc.getId().equals(id)) return doc;
        }
        return null;
    }

    public synchronized void addDocument(DocModel doc) {
        if (doc == null) return;
        documentList.add(0, doc);
        saveToFile();
    }

    public synchronized void updateDocument(DocModel doc) {
        if (doc == null) return;
        for (int i = 0; i < documentList.size(); i++) {
            if (documentList.get(i).getId().equals(doc.getId())) {
                documentList.set(i, doc);
                saveToFile();
                return;
            }
        }
    }

    public synchronized boolean deleteDocument(String id) {
        for (int i = 0; i < documentList.size(); i++) {
            DocModel doc = documentList.get(i);
            if (doc.getId().equals(id)) {
                // Delete physical files
                if (doc.getPdfPath() != null) {
                    File pdfFile = new File(doc.getPdfPath());
                    if (pdfFile.exists()) pdfFile.delete();
                }
                if (doc.getThumbnailPath() != null) {
                    File thumbFile = new File(doc.getThumbnailPath());
                    if (thumbFile.exists()) thumbFile.delete();
                }
                documentList.remove(i);
                saveToFile();
                return true;
            }
        }
        return false;
    }

    public synchronized void renameDocument(String id, String newTitle) {
        DocModel doc = getDocumentById(id);
        if (doc != null) {
            doc.setTitle(newTitle);
            doc.setDateModified(System.currentTimeMillis());
            saveToFile();
        }
    }

    public synchronized List<DocModel> searchDocuments(String query, String tagFilter) {
        List<DocModel> result = new ArrayList<>();
        String lowerQuery = (query != null) ? query.toLowerCase().trim() : "";
        for (DocModel doc : documentList) {
            boolean matchesTag = true;
            if ("scans".equalsIgnoreCase(tagFilter)) {
                matchesTag = "scans".equalsIgnoreCase(doc.getTag());
            } else if ("imported".equalsIgnoreCase(tagFilter)) {
                matchesTag = "imported".equalsIgnoreCase(doc.getTag());
            } else if ("favorites".equalsIgnoreCase(tagFilter)) {
                matchesTag = doc.isFavorite();
            }

            if (matchesTag) {
                if (lowerQuery.isEmpty() || doc.getTitle().toLowerCase().contains(lowerQuery)) {
                    result.add(doc);
                }
            }
        }
        return result;
    }

    public static void sortDocuments(List<DocModel> list, int sortMode) {
        if (list == null || list.isEmpty()) return;
        switch (sortMode) {
            case SORT_DATE_ASC:
                Collections.sort(list, Comparator.comparingLong(DocModel::getDateModified));
                break;
            case SORT_NAME_ASC:
                Collections.sort(list, (a, b) -> a.getTitle().compareToIgnoreCase(b.getTitle()));
                break;
            case SORT_NAME_DESC:
                Collections.sort(list, (a, b) -> b.getTitle().compareToIgnoreCase(a.getTitle()));
                break;
            case SORT_SIZE_DESC:
                Collections.sort(list, (a, b) -> Long.compare(b.getFileSizeBytes(), a.getFileSizeBytes()));
                break;
            case SORT_SIZE_ASC:
                Collections.sort(list, (a, b) -> Long.compare(a.getFileSizeBytes(), b.getFileSizeBytes()));
                break;
            case SORT_DATE_DESC:
            default:
                Collections.sort(list, (a, b) -> Long.compare(b.getDateModified(), a.getDateModified()));
                break;
        }
    }

    public long getDocumentsTotalSize() {
        long total = 0;
        for (DocModel doc : documentList) {
            total += doc.getFileSizeBytes();
        }
        return total;
    }

    public long getCacheTotalSize() {
        return calculateDirectorySize(appContext.getCacheDir());
    }

    public void clearCache() {
        deleteDirectoryContents(appContext.getCacheDir());
    }

    private static long calculateDirectorySize(File dir) {
        if (dir == null || !dir.exists()) return 0;
        long size = 0;
        File[] files = dir.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.isDirectory()) {
                    size += calculateDirectorySize(f);
                } else {
                    size += f.length();
                }
            }
        }
        return size;
    }

    private static void deleteDirectoryContents(File dir) {
        if (dir == null || !dir.exists()) return;
        File[] files = dir.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.isDirectory()) {
                    deleteDirectoryContents(f);
                }
                f.delete();
            }
        }
    }
}
