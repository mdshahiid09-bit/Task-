package com.docflow.android.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.docflow.android.app.adapter.DocumentAdapter;
import com.docflow.android.app.data.DocRepository;
import com.docflow.android.app.engine.ImageEngine;
import com.docflow.android.app.engine.PdfEngine;
import com.docflow.android.app.model.DocModel;
import com.docflow.android.app.util.HapticHelper;
import com.docflow.android.app.util.InsetsHelper;
import com.docflow.android.app.util.ThemeManager;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HomeActivity extends AppCompatActivity implements DocumentAdapter.OnDocActionListener {

    private static final int REQ_IMPORT_PDF = 301;
    private static final int REQ_IMPORT_IMAGES = 302;

    private RecyclerView recyclerDocs;
    private DocumentAdapter adapter;
    private View emptyStateView;
    private EditText editSearch;
    private ImageButton btnClearSearch;
    private ImageButton btnSort;
    private ExtendedFloatingActionButton fabScan;

    private TextView chipAll, chipScans, chipImported, chipFavorites;
    private String currentTagFilter = "all";
    private int currentSortMode = DocRepository.SORT_DATE_DESC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ThemeManager.applyTheme(this);
        DocRepository.getInstance(this);
        setContentView(R.layout.activity_main);

        View root = findViewById(R.id.main_coordinator);
        InsetsHelper.setupEdgeToEdge(this, root);

        initViews();
        setupRecyclerView();
        setupFilterChips();
        setupSearchAndSort();
        setupBottomNav();

        fabScan.setOnClickListener(v -> showQuickActionsSheet());
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshDocumentList();
    }

    private void initViews() {
        recyclerDocs = findViewById(R.id.recycler_documents);
        emptyStateView = findViewById(R.id.empty_state_view);
        editSearch = findViewById(R.id.edit_search);
        btnClearSearch = findViewById(R.id.btn_clear_search);
        btnSort = findViewById(R.id.btn_sort);
        fabScan = findViewById(R.id.fab_scan);

        chipAll = findViewById(R.id.chip_all);
        chipScans = findViewById(R.id.chip_scans);
        chipImported = findViewById(R.id.chip_imported);
        chipFavorites = findViewById(R.id.chip_favorites);
    }

    private void setupRecyclerView() {
        adapter = new DocumentAdapter(this, this);
        recyclerDocs.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerDocs.setAdapter(adapter);
    }

    private void setupFilterChips() {
        View.OnClickListener chipListener = v -> {
            HapticHelper.performClick(v);
            resetChipStyles();
            int id = v.getId();
            if (id == R.id.chip_all) {
                currentTagFilter = "all";
                chipAll.setBackgroundResource(R.drawable.bg_chip_selected);
                chipAll.setTextColor(getResources().getColor(R.color.md_theme_light_onPrimary));
            } else if (id == R.id.chip_scans) {
                currentTagFilter = "scans";
                chipScans.setBackgroundResource(R.drawable.bg_chip_selected);
                chipScans.setTextColor(getResources().getColor(R.color.md_theme_light_onPrimary));
            } else if (id == R.id.chip_imported) {
                currentTagFilter = "imported";
                chipImported.setBackgroundResource(R.drawable.bg_chip_selected);
                chipImported.setTextColor(getResources().getColor(R.color.md_theme_light_onPrimary));
            } else if (id == R.id.chip_favorites) {
                currentTagFilter = "favorites";
                chipFavorites.setBackgroundResource(R.drawable.bg_chip_selected);
                chipFavorites.setTextColor(getResources().getColor(R.color.md_theme_light_onPrimary));
            }
            refreshDocumentList();
        };

        chipAll.setOnClickListener(chipListener);
        chipScans.setOnClickListener(chipListener);
        chipImported.setOnClickListener(chipListener);
        chipFavorites.setOnClickListener(chipListener);
    }

    private void resetChipStyles() {
        int unselectedBg = R.drawable.bg_chip_unselected;
        int unselectedColor = getResources().getColor(R.color.md_theme_light_onSurface);

        chipAll.setBackgroundResource(unselectedBg);
        chipAll.setTextColor(unselectedColor);
        chipScans.setBackgroundResource(unselectedBg);
        chipScans.setTextColor(unselectedColor);
        chipImported.setBackgroundResource(unselectedBg);
        chipImported.setTextColor(unselectedColor);
        chipFavorites.setBackgroundResource(unselectedBg);
        chipFavorites.setTextColor(unselectedColor);
    }

    private void setupSearchAndSort() {
        editSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                btnClearSearch.setVisibility(s.length() > 0 ? View.VISIBLE : View.GONE);
                refreshDocumentList();
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        btnClearSearch.setOnClickListener(v -> editSearch.setText(""));

        btnSort.setOnClickListener(v -> showSortDialog());
    }

    private void setupBottomNav() {
        findViewById(R.id.nav_btn_tools).setOnClickListener(v -> {
            startActivity(new Intent(this, PdfToolsActivity.class));
        });

        findViewById(R.id.nav_btn_storage).setOnClickListener(v -> {
            startActivity(new Intent(this, StorageManagerActivity.class));
        });

        findViewById(R.id.nav_btn_settings).setOnClickListener(v -> {
            startActivity(new Intent(this, SettingsActivity.class));
        });
    }

    private void refreshDocumentList() {
        String query = editSearch.getText().toString().trim();
        List<DocModel> list = DocRepository.getInstance(this).searchDocuments(query, currentTagFilter);
        DocRepository.sortDocuments(list, currentSortMode);

        adapter.setDocuments(list);
        emptyStateView.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void showSortDialog() {
        String[] options = {
            getString(R.string.sort_date_desc),
            getString(R.string.sort_date_asc),
            getString(R.string.sort_name_asc),
            getString(R.string.sort_name_desc),
            getString(R.string.sort_size_desc),
            getString(R.string.sort_size_asc)
        };

        new AlertDialog.Builder(this)
            .setIcon(R.drawable.ic_sort)
            .setTitle("Sort Documents")
            .setSingleChoiceItems(options, currentSortMode, (dialog, which) -> {
                dialog.dismiss();
                currentSortMode = which;
                refreshDocumentList();
            })
            .show();
    }

    private void showQuickActionsSheet() {
        BottomSheetDialog sheet = new BottomSheetDialog(this, R.style.DocFlowBottomSheetDialog);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(32, 32, 32, 48);

        TextView title = new TextView(this);
        title.setText("Quick Actions");
        title.setTextSize(18);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setTextColor(getResources().getColor(R.color.md_theme_light_onSurface));
        title.setPadding(0, 0, 0, 24);
        content.addView(title);

        addSheetItem(content, R.drawable.ic_camera, R.string.action_scan, v -> {
            sheet.dismiss();
            startActivity(new Intent(this, CameraScanActivity.class));
        });

        addSheetItem(content, R.drawable.ic_gallery, R.string.action_import_images, v -> {
            sheet.dismiss();
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/*");
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            startActivityForResult(intent, REQ_IMPORT_IMAGES);
        });

        addSheetItem(content, R.drawable.ic_pdf, R.string.action_import_pdf, v -> {
            sheet.dismiss();
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/pdf");
            startActivityForResult(intent, REQ_IMPORT_PDF);
        });

        addSheetItem(content, R.drawable.ic_merge, R.string.action_quick_merge, v -> {
            sheet.dismiss();
            startActivity(new Intent(this, PdfToolsActivity.class));
        });

        sheet.setContentView(content);
        sheet.show();
    }

    private void addSheetItem(LinearLayout parent, int iconRes, int textRes, View.OnClickListener listener) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(16, 20, 16, 20);
        row.setBackgroundResource(android.R.drawable.list_selector_background);

        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setColorFilter(getResources().getColor(R.color.md_theme_light_primary));
        LinearLayout.LayoutParams icParams = new LinearLayout.LayoutParams(60, 60);
        row.addView(icon, icParams);

        TextView text = new TextView(this);
        text.setText(textRes);
        text.setTextSize(15);
        text.setTextColor(getResources().getColor(R.color.md_theme_light_onSurface));
        text.setPadding(32, 0, 0, 0);
        row.addView(text);

        row.setOnClickListener(listener);
        parent.addView(row);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;

        if (requestCode == REQ_IMPORT_PDF && data.getData() != null) {
            importPdfUri(data.getData());
        } else if (requestCode == REQ_IMPORT_IMAGES) {
            ArrayList<String> importedPaths = new ArrayList<>();
            File scansDir = new File(getCacheDir(), "scans");
            if (!scansDir.exists()) scansDir.mkdirs();

            if (data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                    Uri u = data.getClipData().getItemAt(i).getUri();
                    String path = copyImageUriToCache(u, scansDir);
                    if (path != null) importedPaths.add(path);
                }
            } else if (data.getData() != null) {
                String path = copyImageUriToCache(data.getData(), scansDir);
                if (path != null) importedPaths.add(path);
            }

            if (!importedPaths.isEmpty()) {
                Intent editIntent = new Intent(this, DocumentEditorActivity.class);
                editIntent.putStringArrayListExtra("pages_list", importedPaths);
                startActivity(editIntent);
            }
        }
    }

    private void importPdfUri(Uri uri) {
        try {
            File docsDir = new File(getFilesDir(), "documents");
            if (!docsDir.exists()) docsDir.mkdirs();

            String name = "Imported_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date()) + ".pdf";
            File targetFile = new File(docsDir, name);

            try (InputStream is = getContentResolver().openInputStream(uri);
                 FileOutputStream fos = new FileOutputStream(targetFile)) {
                byte[] buf = new byte[8192];
                int len;
                while ((len = is.read(buf)) != -1) fos.write(buf, 0, len);
                fos.flush();
            }

            String docId = String.valueOf(System.currentTimeMillis());
            File thumb = PdfEngine.generatePdfThumbnail(this, targetFile, docId);

            DocModel doc = new DocModel();
            doc.setId(docId);
            doc.setTitle(name.replace(".pdf", ""));
            doc.setPdfPath(targetFile.getAbsolutePath());
            if (thumb != null) doc.setThumbnailPath(thumb.getAbsolutePath());
            doc.setDateModified(System.currentTimeMillis());
            doc.setPageCount(PdfEngine.getPdfPageCount(targetFile));
            doc.setFileSizeBytes(targetFile.length());
            doc.setTag("imported");

            DocRepository.getInstance(this).addDocument(doc);
            refreshDocumentList();
            Toast.makeText(this, "PDF imported successfully!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, R.string.msg_operation_failed, Toast.LENGTH_SHORT).show();
        }
    }

    private String copyImageUriToCache(Uri uri, File targetDir) {
        try (InputStream is = getContentResolver().openInputStream(uri)) {
            Bitmap bmp = BitmapFactory.decodeStream(is);
            if (bmp != null) {
                File file = new File(targetDir, "import_" + System.currentTimeMillis() + ".jpg");
                ImageEngine.saveBitmapToFile(bmp, file, Bitmap.CompressFormat.JPEG, 92);
                bmp.recycle();
                return file.getAbsolutePath();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void onDocClick(DocModel doc) {
        HapticHelper.performClick(recyclerDocs);
        Intent intent = new Intent(this, PdfViewerActivity.class);
        intent.putExtra("doc_model", doc);
        startActivity(intent);
    }

    @Override
    public void onDocMore(DocModel doc, View anchor) {
        HapticHelper.performClick(anchor);
        String[] actions = {
            getString(R.string.action_open),
            getString(R.string.action_rename),
            getString(R.string.action_duplicate),
            getString(R.string.action_share),
            getString(R.string.action_ocr),
            getString(R.string.action_delete)
        };

        new AlertDialog.Builder(this)
            .setTitle(doc.getTitle())
            .setItems(actions, (dialog, which) -> {
                switch (which) {
                    case 0: // Open
                        onDocClick(doc);
                        break;
                    case 1: // Rename
                        showRenameDialog(doc);
                        break;
                    case 2: // Duplicate
                        duplicateDoc(doc);
                        break;
                    case 3: // Share
                        shareDoc(doc);
                        break;
                    case 4: // OCR
                        extractTextFromDoc(doc);
                        break;
                    case 5: // Delete
                        confirmDeleteDoc(doc);
                        break;
                }
            })
            .show();
    }

    private void showRenameDialog(DocModel doc) {
        EditText input = new EditText(this);
        input.setText(doc.getTitle());
        input.setSelection(doc.getTitle().length());

        new AlertDialog.Builder(this)
            .setTitle(R.string.dialog_rename_title)
            .setView(input)
            .setPositiveButton(R.string.dialog_confirm, (dialog, which) -> {
                String newName = input.getText().toString().trim();
                if (!newName.isEmpty()) {
                    DocRepository.getInstance(this).renameDocument(doc.getId(), newName);
                    refreshDocumentList();
                    Toast.makeText(this, R.string.msg_renamed, Toast.LENGTH_SHORT).show();
                }
            })
            .setNegativeButton(R.string.dialog_cancel, null)
            .show();
    }

    private void duplicateDoc(DocModel doc) {
        try {
            File src = new File(doc.getPdfPath());
            if (!src.exists()) return;

            File docsDir = new File(getFilesDir(), "documents");
            String newTitle = doc.getTitle() + " (Copy)";
            File dest = new File(docsDir, newTitle + ".pdf");

            try (InputStream is = new java.io.FileInputStream(src);
                 FileOutputStream fos = new FileOutputStream(dest)) {
                byte[] buf = new byte[8192];
                int len;
                while ((len = is.read(buf)) != -1) fos.write(buf, 0, len);
                fos.flush();
            }

            String docId = String.valueOf(System.currentTimeMillis());
            File thumb = PdfEngine.generatePdfThumbnail(this, dest, docId);

            DocModel copy = new DocModel();
            copy.setId(docId);
            copy.setTitle(newTitle);
            copy.setPdfPath(dest.getAbsolutePath());
            if (thumb != null) copy.setThumbnailPath(thumb.getAbsolutePath());
            copy.setDateModified(System.currentTimeMillis());
            copy.setPageCount(doc.getPageCount());
            copy.setFileSizeBytes(dest.length());
            copy.setTag(doc.getTag());

            DocRepository.getInstance(this).addDocument(copy);
            refreshDocumentList();
            Toast.makeText(this, R.string.msg_duplicated, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void shareDoc(DocModel doc) {
        try {
            File pdfFile = new File(doc.getPdfPath());
            Uri contentUri = FileProvider.getUriForFile(this, "com.docflow.android.app.fileprovider", pdfFile);

            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("application/pdf");
            shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(shareIntent, getString(R.string.action_share)));
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Unable to share document", Toast.LENGTH_SHORT).show();
        }
    }

    private void extractTextFromDoc(DocModel doc) {
        Toast.makeText(this, "Extracting page for offline OCR…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            File pdfFile = new File(doc.getPdfPath());
            Bitmap pageBmp = PdfEngine.renderPdfPageToBitmap(pdfFile, 0, 1600);
            if (pageBmp != null) {
                File cacheDir = new File(getCacheDir(), "ocr_temp");
                if (!cacheDir.exists()) cacheDir.mkdirs();
                File tempBmp = new File(cacheDir, "page_ocr.jpg");
                ImageEngine.saveBitmapToFile(pageBmp, tempBmp, Bitmap.CompressFormat.JPEG, 90);
                pageBmp.recycle();

                runOnUiThread(() -> {
                    Intent ocrIntent = new Intent(this, OcrResultActivity.class);
                    ocrIntent.putExtra("image_path", tempBmp.getAbsolutePath());
                    startActivity(ocrIntent);
                });
            }
        }).start();
    }

    private void confirmDeleteDoc(DocModel doc) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_confirm_delete, null);
        AlertDialog dialog = new AlertDialog.Builder(this)
            .setView(dialogView)
            .create();

        TextView title = dialogView.findViewById(R.id.dialog_title);
        TextView message = dialogView.findViewById(R.id.dialog_message);
        Button btnCancel = dialogView.findViewById(R.id.btn_confirm_cancel);
        Button btnConfirm = dialogView.findViewById(R.id.btn_confirm_action);

        title.setText(R.string.dialog_delete_title);
        message.setText(getString(R.string.dialog_delete_msg, doc.getTitle()));
        btnConfirm.setText(R.string.action_delete);

        btnCancel.setOnClickListener(v -> dialog.dismiss());
        btnConfirm.setOnClickListener(v -> {
            dialog.dismiss();
            DocRepository.getInstance(this).deleteDocument(doc.getId());
            refreshDocumentList();
            Toast.makeText(this, R.string.msg_deleted, Toast.LENGTH_SHORT).show();
        });

        dialog.show();
    }
}
