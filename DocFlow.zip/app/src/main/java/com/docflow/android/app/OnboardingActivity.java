package com.docflow.android.app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import com.docflow.android.app.util.InsetsHelper;
import java.util.ArrayList;
import java.util.List;

public class OnboardingActivity extends AppCompatActivity {

    private static final String PREF_ONBOARDING = "docflow_onboarding_pref";
    private static final String KEY_COMPLETED = "is_completed";

    private ViewPager2 viewPager;
    private LinearLayout dotsLayout;
    private Button btnNext;
    private TextView btnSkip;

    private static class SlideItem {
        int iconRes;
        int titleRes;
        int descRes;
        SlideItem(int icon, int title, int desc) {
            iconRes = icon; titleRes = title; descRes = desc;
        }
    }

    private final List<SlideItem> slides = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding);

        View root = findViewById(R.id.onboarding_root);
        InsetsHelper.setupEdgeToEdge(this, root);

        slides.add(new SlideItem(R.drawable.ic_camera, R.string.onboarding_title_1, R.string.onboarding_desc_1));
        slides.add(new SlideItem(R.drawable.ic_merge, R.string.onboarding_title_2, R.string.onboarding_desc_2));
        slides.add(new SlideItem(R.drawable.ic_ocr, R.string.onboarding_title_3, R.string.onboarding_desc_3));

        viewPager = findViewById(R.id.onboarding_pager);
        dotsLayout = findViewById(R.id.dots_container);
        btnNext = findViewById(R.id.btn_next);
        btnSkip = findViewById(R.id.btn_skip);

        viewPager.setAdapter(new OnboardingSliderAdapter(slides));
        setupDots(0);

        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                setupDots(position);
                if (position == slides.size() - 1) {
                    btnNext.setText(R.string.onboarding_get_started);
                    btnSkip.setVisibility(View.GONE);
                } else {
                    btnNext.setText(R.string.onboarding_next);
                    btnSkip.setVisibility(View.VISIBLE);
                }
            }
        });

        btnNext.setOnClickListener(v -> {
            int current = viewPager.getCurrentItem();
            if (current < slides.size() - 1) {
                viewPager.setCurrentItem(current + 1);
            } else {
                finishOnboarding();
            }
        });

        btnSkip.setOnClickListener(v -> finishOnboarding());
    }

    private void setupDots(int activeIndex) {
        dotsLayout.removeAllViews();
        for (int i = 0; i < slides.size(); i++) {
            View dot = new View(this);
            int size = (i == activeIndex) ? 24 : 10;
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                (int) (size * getResources().getDisplayMetrics().density),
                (int) (10 * getResources().getDisplayMetrics().density)
            );
            params.setMargins(8, 0, 8, 0);
            dot.setLayoutParams(params);
            dot.setBackgroundResource((i == activeIndex) ? R.drawable.bg_chip_selected : R.drawable.bg_chip_unselected);
            dotsLayout.addView(dot);
        }
    }

    private void finishOnboarding() {
        SharedPreferences prefs = getSharedPreferences(PREF_ONBOARDING, MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_COMPLETED, true).apply();

        startActivity(new Intent(this, HomeActivity.class));
        finish();
    }

    private static class OnboardingSliderAdapter extends RecyclerView.Adapter<OnboardingSliderAdapter.SlideViewHolder> {
        private final List<SlideItem> items;
        OnboardingSliderAdapter(List<SlideItem> items) { this.items = items; }

        @Override
        public SlideViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_onboarding_slide, parent, false);
            return new SlideViewHolder(v);
        }

        @Override
        public void onBindViewHolder(SlideViewHolder holder, int position) {
            SlideItem item = items.get(position);
            holder.image.setImageResource(item.iconRes);
            holder.title.setText(item.titleRes);
            holder.desc.setText(item.descRes);
        }

        @Override
        public int getItemCount() { return items.size(); }

        static class SlideViewHolder extends RecyclerView.ViewHolder {
            ImageView image;
            TextView title;
            TextView desc;
            SlideViewHolder(View v) {
                super(v);
                image = v.findViewById(R.id.slide_image);
                title = v.findViewById(R.id.slide_title);
                desc = v.findViewById(R.id.slide_desc);
            }
        }
    }
}
