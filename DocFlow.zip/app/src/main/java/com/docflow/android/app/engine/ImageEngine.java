package com.docflow.android.app.engine;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import com.docflow.android.app.model.DocPage;
import java.io.File;
import java.io.FileOutputStream;

public class ImageEngine {

    public static Bitmap decodeSampledBitmapFromFile(String path, int reqWidth, int reqHeight) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, options);

        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
        options.inJustDecodeBounds = false;
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        return BitmapFactory.decodeFile(path, options);
    }

    public static int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;

            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }

    public static Bitmap rotateBitmap(Bitmap source, int angle) {
        if (angle % 360 == 0 || source == null) return source;
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
    }

    public static Bitmap applyPageAdjustments(Bitmap source, DocPage page) {
        if (source == null || page == null) return source;
        Bitmap result = source;

        // 1. Rotation
        if (page.getRotationDegrees() != 0) {
            result = rotateBitmap(result, page.getRotationDegrees());
        }

        // 2. Filter
        switch (page.getFilterType()) {
            case DocPage.FILTER_AUTO_ENHANCE:
                result = applyAutoEnhance(result);
                break;
            case DocPage.FILTER_BW_DOC:
                result = applyBwDocument(result);
                break;
            case DocPage.FILTER_GRAYSCALE:
                result = applyGrayscale(result);
                break;
            case DocPage.FILTER_MAGIC_COLOR:
                result = applyMagicColor(result);
                break;
            case DocPage.FILTER_ORIGINAL:
            default:
                break;
        }

        // 3. Brightness and Contrast
        if (page.getBrightness() != 100 || page.getContrast() != 100) {
            result = adjustBrightnessContrast(result, page.getBrightness(), page.getContrast());
        }

        return result;
    }

    public static Bitmap applyGrayscale(Bitmap src) {
        Bitmap dest = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(dest);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(0);
        paint.setColorFilter(new ColorMatrixColorFilter(cm));
        canvas.drawBitmap(src, 0, 0, paint);
        return dest;
    }

    public static Bitmap applyAutoEnhance(Bitmap src) {
        Bitmap dest = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(dest);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        // Boost contrast slightly (1.2x) and saturation (1.1x)
        ColorMatrix cmContrast = new ColorMatrix(new float[]{
            1.25f, 0, 0, 0, -25f,
            0, 1.25f, 0, 0, -25f,
            0, 0, 1.25f, 0, -25f,
            0, 0, 0, 1.0f, 0
        });
        ColorMatrix cmSat = new ColorMatrix();
        cmSat.setSaturation(1.15f);
        cmContrast.postConcat(cmSat);

        paint.setColorFilter(new ColorMatrixColorFilter(cmContrast));
        canvas.drawBitmap(src, 0, 0, paint);
        return dest;
    }

    public static Bitmap applyMagicColor(Bitmap src) {
        Bitmap dest = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(dest);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        // High contrast document enhancement
        ColorMatrix cm = new ColorMatrix(new float[]{
            1.4f, 0, 0, 0, -35f,
            0, 1.4f, 0, 0, -35f,
            0, 0, 1.4f, 0, -35f,
            0, 0, 0, 1.0f, 0
        });
        ColorMatrix cmSat = new ColorMatrix();
        cmSat.setSaturation(1.3f);
        cm.postConcat(cmSat);

        paint.setColorFilter(new ColorMatrixColorFilter(cm));
        canvas.drawBitmap(src, 0, 0, paint);
        return dest;
    }

    /**
     * Crisp Black & White document binarization with Otsu adaptive thresholding.
     * Cleanly removes uneven camera shadows and yields pure paper white with sharp black text.
     */
    public static Bitmap applyBwDocument(Bitmap src) {
        int width = src.getWidth();
        int height = src.getHeight();
        int[] pixels = new int[width * height];
        src.getPixels(pixels, 0, width, 0, 0, width, height);

        // Compute histogram
        int[] histogram = new int[256];
        int total = width * height;
        for (int p : pixels) {
            int r = (p >> 16) & 0xFF;
            int g = (p >> 8) & 0xFF;
            int b = p & 0xFF;
            int gray = (int) (0.299 * r + 0.587 * g + 0.114 * b);
            histogram[gray]++;
        }

        // Otsu's threshold computation
        float sum = 0;
        for (int i = 0; i < 256; i++) sum += i * histogram[i];

        float sumB = 0;
        int wB = 0;
        float varMax = 0;
        int threshold = 128;

        for (int t = 0; t < 256; t++) {
            wB += histogram[t];
            if (wB == 0) continue;
            int wF = total - wB;
            if (wF == 0) break;

            sumB += (float) (t * histogram[t]);
            float mB = sumB / wB;
            float mF = (sum - sumB) / wF;

            float varBetween = (float) wB * (float) wF * (mB - mF) * (mB - mF);
            if (varBetween > varMax) {
                varMax = varBetween;
                threshold = t;
            }
        }

        // Bias slightly towards brighter paper
        threshold = Math.min(220, threshold + 15);

        // Apply threshold
        for (int i = 0; i < pixels.length; i++) {
            int p = pixels[i];
            int r = (p >> 16) & 0xFF;
            int g = (p >> 8) & 0xFF;
            int b = p & 0xFF;
            int gray = (int) (0.299 * r + 0.587 * g + 0.114 * b);
            if (gray > threshold) {
                pixels[i] = Color.WHITE;
            } else {
                pixels[i] = Color.BLACK;
            }
        }

        return Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888);
    }

    public static Bitmap adjustBrightnessContrast(Bitmap src, int brightness, int contrast) {
        Bitmap dest = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(dest);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        // brightness: 0 to 200, 100 neutral -> scale -100 to +100
        float bOffset = (brightness - 100.0f) * 1.5f;

        // contrast: 0 to 200, 100 neutral -> scale 0.0 to 2.0
        float cScale = contrast / 100.0f;
        float cOffset = 128.0f * (1.0f - cScale);

        ColorMatrix cm = new ColorMatrix(new float[]{
            cScale, 0, 0, 0, cOffset + bOffset,
            0, cScale, 0, 0, cOffset + bOffset,
            0, 0, cScale, 0, cOffset + bOffset,
            0, 0, 0, 1.0f, 0
        });

        paint.setColorFilter(new ColorMatrixColorFilter(cm));
        canvas.drawBitmap(src, 0, 0, paint);
        return dest;
    }

    public static boolean saveBitmapToFile(Bitmap bitmap, File file, Bitmap.CompressFormat format, int quality) {
        if (bitmap == null || file == null) return false;
        try {
            if (file.exists()) file.delete();
            File parent = file.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();

            try (FileOutputStream fos = new FileOutputStream(file)) {
                bitmap.compress(format, quality, fos);
                fos.flush();
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
