package com.docflow.android.app.model;

import java.io.Serializable;

public class DocPage implements Serializable {
    public static final int FILTER_ORIGINAL = 0;
    public static final int FILTER_AUTO_ENHANCE = 1;
    public static final int FILTER_BW_DOC = 2;
    public static final int FILTER_GRAYSCALE = 3;
    public static final int FILTER_MAGIC_COLOR = 4;

    private int pageIndex;
    private String imagePath;
    private String originalPath;
    private int rotationDegrees;
    private int filterType;
    private int brightness; // 0 to 200, 100 is neutral
    private int contrast;   // 0 to 200, 100 is neutral

    public DocPage() {
        this.pageIndex = 0;
        this.rotationDegrees = 0;
        this.filterType = FILTER_ORIGINAL;
        this.brightness = 100;
        this.contrast = 100;
    }

    public DocPage(int pageIndex, String imagePath) {
        this.pageIndex = pageIndex;
        this.imagePath = imagePath;
        this.originalPath = imagePath;
        this.rotationDegrees = 0;
        this.filterType = FILTER_ORIGINAL;
        this.brightness = 100;
        this.contrast = 100;
    }

    public int getPageIndex() { return pageIndex; }
    public void setPageIndex(int pageIndex) { this.pageIndex = pageIndex; }

    public String getImagePath() { return imagePath; }
    public void setImagePath(String imagePath) { this.imagePath = imagePath; }

    public String getOriginalPath() { return originalPath != null ? originalPath : imagePath; }
    public void setOriginalPath(String originalPath) { this.originalPath = originalPath; }

    public int getRotationDegrees() { return rotationDegrees; }
    public void setRotationDegrees(int rotationDegrees) { this.rotationDegrees = rotationDegrees % 360; }
    public void rotateClockwise() { this.rotationDegrees = (this.rotationDegrees + 90) % 360; }

    public int getFilterType() { return filterType; }
    public void setFilterType(int filterType) { this.filterType = filterType; }

    public int getBrightness() { return brightness; }
    public void setBrightness(int brightness) { this.brightness = brightness; }

    public int getContrast() { return contrast; }
    public void setContrast(int contrast) { this.contrast = contrast; }

    public DocPage copy() {
        DocPage cp = new DocPage(this.pageIndex, this.imagePath);
        cp.setOriginalPath(this.originalPath);
        cp.setRotationDegrees(this.rotationDegrees);
        cp.setFilterType(this.filterType);
        cp.setBrightness(this.brightness);
        cp.setContrast(this.contrast);
        return cp;
    }
}
