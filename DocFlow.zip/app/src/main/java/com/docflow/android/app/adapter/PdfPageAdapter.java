package com.docflow.android.app.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView;
import com.docflow.android.app.R;
import com.docflow.android.app.engine.PdfEngine;
import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PdfPageAdapter extends RecyclerView.Adapter<PdfPageAdapter.PdfPageViewHolder> {

    private final Context context;
    private final File pdfFile;
    private final int pageCount;
    private final ExecutorService executor = Executors.newFixedThreadPool(2);
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public PdfPageAdapter(Context context, File pdfFile, int pageCount) {
        this.context = context;
        this.pdfFile = pdfFile;
        this.pageCount = pageCount;
    }

    @Override
    public PdfPageViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_pdf_page, parent, false);
        return new PdfPageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(PdfPageViewHolder holder, int position) {
        final int pageIndex = position;
        holder.imagePage.setImageBitmap(null);

        executor.execute(() -> {
            // Render at full device display width
            int screenWidth = context.getResources().getDisplayMetrics().widthPixels;
            final Bitmap pageBmp = PdfEngine.renderPdfPageToBitmap(pdfFile, pageIndex, Math.max(720, screenWidth));
            mainHandler.post(() -> {
                if (holder.getAdapterPosition() == pageIndex && pageBmp != null) {
                    holder.imagePage.setImageBitmap(pageBmp);
                }
            });
        });
    }

    @Override
    public int getItemCount() {
        return pageCount;
    }

    public static class PdfPageViewHolder extends RecyclerView.ViewHolder {
        ImageView imagePage;

        public PdfPageViewHolder(View itemView) {
            super(itemView);
            imagePage = itemView.findViewById(R.id.image_pdf_page);
        }
    }
}
