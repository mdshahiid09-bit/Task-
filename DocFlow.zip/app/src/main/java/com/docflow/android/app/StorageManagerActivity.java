package com.docflow.android.app;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.docflow.android.app.data.DocRepository;
import com.docflow.android.app.util.InsetsHelper;
import java.util.Locale;

public class StorageManagerActivity extends AppCompatActivity {

    private TextView textTotalSize;
    private TextView textDocSize;
    private TextView textCacheSize;
    private ProgressBar progressBar;
    private Button btnClearCache;
    private ImageButton btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_storage_manager);

        View root = findViewById(R.id.storage_root);
        InsetsHelper.setupEdgeToEdge(this, root);

        textTotalSize = findViewById(R.id.text_total_storage_size);
        textDocSize = findViewById(R.id.text_doc_storage_size);
        textCacheSize = findViewById(R.id.text_cache_storage_size);
        progressBar = findViewById(R.id.storage_progress_bar);
        btnClearCache = findViewById(R.id.btn_clear_cache);
        btnBack = findViewById(R.id.btn_storage_back);

        btnBack.setOnClickListener(v -> finish());
        btnClearCache.setOnClickListener(v -> confirmClearCache());

        updateStorageStats();
    }

    private void updateStorageStats() {
        DocRepository repo = DocRepository.getInstance(this);
        long docBytes = repo.getDocumentsTotalSize();
        long cacheBytes = repo.getCacheTotalSize();
        long totalBytes = docBytes + cacheBytes;

        textTotalSize.setText(formatBytes(totalBytes));
        textDocSize.setText(formatBytes(docBytes));
        textCacheSize.setText(formatBytes(cacheBytes));

        if (totalBytes > 0) {
            int cachePercent = (int) ((cacheBytes * 100) / totalBytes);
            progressBar.setProgress(cachePercent);
        } else {
            progressBar.setProgress(0);
        }
    }

    private void confirmClearCache() {
        new AlertDialog.Builder(this)
            .setTitle(R.string.storage_clear_cache)
            .setMessage("Are you sure you want to delete all temporary scan files and rendering cache? Your saved documents will not be affected.")
            .setPositiveButton("Clear", (dialog, which) -> {
                DocRepository.getInstance(this).clearCache();
                updateStorageStats();
                Toast.makeText(this, R.string.storage_cache_cleared, Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton(R.string.dialog_cancel, null)
            .show();
    }

    private String formatBytes(long bytes) {
        if (bytes <= 0) return "0 KB";
        if (bytes < 1024 * 1024) {
            return String.format(Locale.getDefault(), "%.1f KB", bytes / 1024.0);
        }
        return String.format(Locale.getDefault(), "%.1f MB", bytes / (1024.0 * 1024.0));
    }
}
