package com.docflow.android.app;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.docflow.android.app.adapter.PdfPageAdapter;
import com.docflow.android.app.engine.ImageEngine;
import com.docflow.android.app.engine.PdfEngine;
import com.docflow.android.app.model.DocModel;
import com.docflow.android.app.util.InsetsHelper;
import java.io.File;

public class PdfViewerActivity extends AppCompatActivity {

    private RecyclerView recyclerPdf;
    private TextView textIndicator;
    private TextView textTitle;
    private ImageButton btnBack;
    private ImageButton btnShare;
    private ImageButton btnOcr;

    private DocModel currentDoc;
    private File currentPdfFile;
    private int totalPages = 0;
    private LinearLayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pdf_viewer);

        View root = findViewById(R.id.viewer_root);
        InsetsHelper.setupImmersiveFullscreen(this, root);

        recyclerPdf = findViewById(R.id.recycler_pdf_pages);
        textIndicator = findViewById(R.id.viewer_page_indicator_text);
        textTitle = findViewById(R.id.viewer_title_text);
        btnBack = findViewById(R.id.btn_viewer_back);
        btnShare = findViewById(R.id.btn_viewer_share);
        btnOcr = findViewById(R.id.btn_viewer_ocr);

        currentDoc = (DocModel) getIntent().getSerializableExtra("doc_model");
        String directPath = getIntent().getStringExtra("pdf_path");

        if (currentDoc != null && currentDoc.getPdfPath() != null) {
            currentPdfFile = new File(currentDoc.getPdfPath());
            textTitle.setText(currentDoc.getTitle());
        } else if (directPath != null) {
            currentPdfFile = new File(directPath);
            textTitle.setText(currentPdfFile.getName().replace(".pdf", ""));
        }

        if (currentPdfFile == null || !currentPdfFile.exists()) {
            Toast.makeText(this, R.string.msg_invalid_file, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        totalPages = PdfEngine.getPdfPageCount(currentPdfFile);
        if (totalPages <= 0) {
            Toast.makeText(this, R.string.msg_invalid_file, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        layoutManager = new LinearLayoutManager(this);
        recyclerPdf.setLayoutManager(layoutManager);
        recyclerPdf.setAdapter(new PdfPageAdapter(this, currentPdfFile, totalPages));

        updateIndicator(1);

        recyclerPdf.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                int firstVisible = layoutManager.findFirstVisibleItemPosition();
                if (firstVisible >= 0) {
                    updateIndicator(firstVisible + 1);
                }
            }
        });

        btnBack.setOnClickListener(v -> finish());
        btnShare.setOnClickListener(v -> sharePdf());
        btnOcr.setOnClickListener(v -> runOcrOnCurrentPage());
    }

    private void updateIndicator(int currentPage) {
        textIndicator.setText(getString(R.string.viewer_page_indicator, currentPage, totalPages));
    }

    private void sharePdf() {
        try {
            Uri contentUri = FileProvider.getUriForFile(
                this, "com.docflow.android.app.fileprovider", currentPdfFile
            );
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("application/pdf");
            shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(shareIntent, getString(R.string.action_share)));
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Could not share file", Toast.LENGTH_SHORT).show();
        }
    }

    private void runOcrOnCurrentPage() {
        int visiblePage = layoutManager.findFirstVisibleItemPosition();
        if (visiblePage < 0) visiblePage = 0;

        Toast.makeText(this, "Rendering page for offline OCR…", Toast.LENGTH_SHORT).show();
        final int targetPageIndex = visiblePage;

        new Thread(() -> {
            Bitmap pageBmp = PdfEngine.renderPdfPageToBitmap(currentPdfFile, targetPageIndex, 1600);
            if (pageBmp != null) {
                File cacheDir = new File(getCacheDir(), "ocr_temp");
                if (!cacheDir.exists()) cacheDir.mkdirs();
                File tempBmp = new File(cacheDir, "page_ocr.jpg");
                ImageEngine.saveBitmapToFile(pageBmp, tempBmp, Bitmap.CompressFormat.JPEG, 90);
                pageBmp.recycle();

                runOnUiThread(() -> {
                    Intent ocrIntent = new Intent(PdfViewerActivity.this, OcrResultActivity.class);
                    ocrIntent.putExtra("image_path", tempBmp.getAbsolutePath());
                    startActivity(ocrIntent);
                });
            }
        }).start();
    }
}
