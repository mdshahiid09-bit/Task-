package com.docflow.android.app.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.docflow.android.app.R;
import com.docflow.android.app.engine.ImageEngine;
import com.docflow.android.app.model.DocPage;
import com.google.android.material.card.MaterialCardView;
import java.util.ArrayList;
import java.util.List;

public class PageThumbAdapter extends RecyclerView.Adapter<PageThumbAdapter.ThumbViewHolder> {

    public interface OnPageSelectedListener {
        void onPageSelected(int position);
    }

    private final Context context;
    private List<DocPage> pages = new ArrayList<>();
    private int selectedPosition = 0;
    private final OnPageSelectedListener listener;

    public PageThumbAdapter(Context context, OnPageSelectedListener listener) {
        this.context = context;
        this.listener = listener;
    }

    public void setPages(List<DocPage> pages, int selected) {
        this.pages = (pages != null) ? pages : new ArrayList<>();
        this.selectedPosition = selected;
        notifyDataSetChanged();
    }

    public void setSelectedPosition(int position) {
        this.selectedPosition = position;
        notifyDataSetChanged();
    }

    public int getSelectedPosition() {
        return selectedPosition;
    }

    @Override
    public ThumbViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_editor_page, parent, false);
        return new ThumbViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ThumbViewHolder holder, int position) {
        DocPage page = pages.get(position);
        holder.textNumber.setText(String.valueOf(position + 1));

        if (position == selectedPosition) {
            holder.cardRoot.setStrokeColor(Color.parseColor("#006495"));
            holder.cardRoot.setStrokeWidth(4);
        } else {
            holder.cardRoot.setStrokeColor(Color.TRANSPARENT);
            holder.cardRoot.setStrokeWidth(0);
        }

        Bitmap raw = ImageEngine.decodeSampledBitmapFromFile(page.getImagePath(), 100, 150);
        if (raw != null) {
            if (page.getRotationDegrees() != 0) {
                Bitmap rot = ImageEngine.rotateBitmap(raw, page.getRotationDegrees());
                holder.imageThumb.setImageBitmap(rot);
                if (rot != raw) raw.recycle();
            } else {
                holder.imageThumb.setImageBitmap(raw);
            }
        }

        holder.cardRoot.setOnClickListener(v -> {
            int currentPos = holder.getAdapterPosition();
            if (currentPos != RecyclerView.NO_POSITION) {
                selectedPosition = currentPos;
                notifyDataSetChanged();
                if (listener != null) listener.onPageSelected(currentPos);
            }
        });
    }

    @Override
    public int getItemCount() {
        return pages.size();
    }

    public static class ThumbViewHolder extends RecyclerView.ViewHolder {
        MaterialCardView cardRoot;
        ImageView imageThumb;
        TextView textNumber;

        public ThumbViewHolder(View itemView) {
            super(itemView);
            cardRoot = itemView.findViewById(R.id.card_thumb);
            imageThumb = itemView.findViewById(R.id.thumb_image);
            textNumber = itemView.findViewById(R.id.thumb_number);
        }
    }
}
