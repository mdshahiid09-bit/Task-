package com.docflow.android.app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import com.docflow.android.app.util.InsetsHelper;
import com.docflow.android.app.util.ThemeManager;

public class SplashActivity extends AppCompatActivity {

    private static final String PREF_ONBOARDING = "docflow_onboarding_pref";
    private static final String KEY_COMPLETED = "is_completed";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeManager.applyTheme(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        View root = findViewById(R.id.splash_root);
        InsetsHelper.setupImmersiveFullscreen(this, root);

        ImageView logo = findViewById(R.id.splash_logo);
        if (logo != null) {
            ScaleAnimation scale = new ScaleAnimation(
                0.8f, 1.0f, 0.8f, 1.0f,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f
            );
            scale.setDuration(800);
            scale.setFillAfter(true);

            AlphaAnimation alpha = new AlphaAnimation(0.2f, 1.0f);
            alpha.setDuration(800);
            alpha.setFillAfter(true);

            logo.startAnimation(scale);
        }

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            SharedPreferences prefs = getSharedPreferences(PREF_ONBOARDING, MODE_PRIVATE);
            boolean isCompleted = prefs.getBoolean(KEY_COMPLETED, false);

            Intent intent;
            if (!isCompleted) {
                intent = new Intent(SplashActivity.this, OnboardingActivity.class);
            } else {
                intent = new Intent(SplashActivity.this, HomeActivity.class);
            }
            startActivity(intent);
            finish();
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        }, 1200);
    }
}
