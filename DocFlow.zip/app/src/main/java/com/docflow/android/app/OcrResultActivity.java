package com.docflow.android.app;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.docflow.android.app.engine.OfflineOcrEngine;
import com.docflow.android.app.util.InsetsHelper;
import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class OcrResultActivity extends AppCompatActivity {

    private EditText editContent;
    private TextView textStats;
    private ProgressBar loadingBar;
    private ImageButton btnBack;
    private ImageButton btnCopy;
    private ImageButton btnShare;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ocr_result);

        View root = findViewById(R.id.ocr_root);
        InsetsHelper.setupEdgeToEdge(this, root);

        editContent = findViewById(R.id.edit_ocr_content);
        textStats = findViewById(R.id.ocr_stats_text);
        loadingBar = findViewById(R.id.ocr_loading_bar);
        btnBack = findViewById(R.id.btn_ocr_back);
        btnCopy = findViewById(R.id.btn_ocr_copy);
        btnShare = findViewById(R.id.btn_ocr_share);

        btnBack.setOnClickListener(v -> finish());
        btnCopy.setOnClickListener(v -> copyTextToClipboard());
        btnShare.setOnClickListener(v -> shareExtractedText());

        String imagePath = getIntent().getStringExtra("image_path");
        if (imagePath != null && new File(imagePath).exists()) {
            runOcr(imagePath);
        } else {
            editContent.setText(R.string.ocr_empty);
        }
    }

    private void runOcr(String imagePath) {
        loadingBar.setVisibility(View.VISIBLE);
        textStats.setText(R.string.ocr_processing);

        executor.execute(() -> {
            Bitmap bmp = BitmapFactory.decodeFile(imagePath);
            final OfflineOcrEngine.OcrResult result = OfflineOcrEngine.extractTextFromBitmap(bmp);
            if (bmp != null) bmp.recycle();

            mainHandler.post(() -> {
                loadingBar.setVisibility(View.GONE);
                if (result != null && result.isSuccess) {
                    editContent.setText(result.text);
                    textStats.setText(getString(R.string.ocr_stats, result.wordCount, result.charCount));
                } else {
                    editContent.setText(R.string.ocr_empty);
                    textStats.setText("0 words • 0 characters");
                }
            });
        });
    }

    private void copyTextToClipboard() {
        String text = editContent.getText().toString();
        if (text.isEmpty()) return;

        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("DocFlow OCR Text", text);
        if (clipboard != null) {
            clipboard.setPrimaryClip(clip);
            Toast.makeText(this, R.string.ocr_copied, Toast.LENGTH_SHORT).show();
        }
    }

    private void shareExtractedText() {
        String text = editContent.getText().toString();
        if (text.isEmpty()) return;

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(intent, getString(R.string.ocr_share)));
    }
}
