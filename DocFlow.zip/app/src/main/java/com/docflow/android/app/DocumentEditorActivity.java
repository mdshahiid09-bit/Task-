package com.docflow.android.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.docflow.android.app.adapter.PageThumbAdapter;
import com.docflow.android.app.data.DocRepository;
import com.docflow.android.app.engine.ImageEngine;
import com.docflow.android.app.engine.PdfEngine;
import com.docflow.android.app.model.DocModel;
import com.docflow.android.app.model.DocPage;
import com.docflow.android.app.util.HapticHelper;
import com.docflow.android.app.util.InsetsHelper;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DocumentEditorActivity extends AppCompatActivity {

    private ImageView imagePreview;
    private ProgressBar progress;
    private RecyclerView recyclerThumbs;
    private PageThumbAdapter thumbAdapter;

    private LinearLayout adjustmentPanel;
    private SeekBar seekBrightness;
    private SeekBar seekContrast;

    private TextView textPageTitle;
    private Button btnSavePdf;
    private ImageButton btnBack;

    private final List<DocPage> pageList = new ArrayList<>();
    private int currentPosition = 0;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_document_editor);

        View root = findViewById(R.id.editor_root);
        InsetsHelper.setupEdgeToEdge(this, root);

        imagePreview = findViewById(R.id.image_page_preview);
        progress = findViewById(R.id.editor_progress);
        recyclerThumbs = findViewById(R.id.recycler_page_thumbs);
        adjustmentPanel = findViewById(R.id.adjustment_panel);
        seekBrightness = findViewById(R.id.seek_brightness);
        seekContrast = findViewById(R.id.seek_contrast);
        textPageTitle = findViewById(R.id.editor_page_title);
        btnSavePdf = findViewById(R.id.btn_editor_save_pdf);
        btnBack = findViewById(R.id.btn_editor_back);

        ArrayList<String> paths = getIntent().getStringArrayListExtra("pages_list");
        if (paths != null) {
            for (int i = 0; i < paths.size(); i++) {
                pageList.add(new DocPage(i, paths.get(i)));
            }
        }

        if (pageList.isEmpty()) {
            Toast.makeText(this, "No pages available to edit", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        setupRecyclerView();
        setupTools();

        btnBack.setOnClickListener(v -> finish());
        btnSavePdf.setOnClickListener(v -> showExportDialog());

        loadCurrentPage();
    }

    private void setupRecyclerView() {
        thumbAdapter = new PageThumbAdapter(this, position -> {
            currentPosition = position;
            loadCurrentPage();
        });
        recyclerThumbs.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        recyclerThumbs.setAdapter(thumbAdapter);
        thumbAdapter.setPages(pageList, currentPosition);
    }

    private void setupTools() {
        findViewById(R.id.tool_rotate).setOnClickListener(v -> {
            HapticHelper.performClick(v);
            if (currentPosition < pageList.size()) {
                DocPage page = pageList.get(currentPosition);
                page.rotateClockwise();
                thumbAdapter.notifyItemChanged(currentPosition);
                loadCurrentPage();
            }
        });

        findViewById(R.id.tool_filter).setOnClickListener(v -> {
            HapticHelper.performClick(v);
            showFilterMenu();
        });

        findViewById(R.id.tool_tune).setOnClickListener(v -> {
            HapticHelper.performClick(v);
            if (adjustmentPanel.getVisibility() == View.VISIBLE) {
                adjustmentPanel.setVisibility(View.GONE);
            } else {
                adjustmentPanel.setVisibility(View.VISIBLE);
                if (currentPosition < pageList.size()) {
                    DocPage p = pageList.get(currentPosition);
                    seekBrightness.setProgress(p.getBrightness());
                    seekContrast.setProgress(p.getContrast());
                }
            }
        });

        seekBrightness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && currentPosition < pageList.size()) {
                    pageList.get(currentPosition).setBrightness(progress);
                    loadCurrentPage();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        seekContrast.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && currentPosition < pageList.size()) {
                    pageList.get(currentPosition).setContrast(progress);
                    loadCurrentPage();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        findViewById(R.id.tool_delete_page).setOnClickListener(v -> {
            HapticHelper.performClick(v);
            confirmDeletePage();
        });

        findViewById(R.id.tool_add_page).setOnClickListener(v -> {
            HapticHelper.performClick(v);
            Intent intent = new Intent(this, CameraScanActivity.class);
            startActivity(intent);
            finish();
        });
    }

    private void showFilterMenu() {
        String[] filters = {"Original", "Auto Enhance", "B&W Document", "Grayscale", "Magic Color"};
        new AlertDialog.Builder(this)
            .setTitle(R.string.editor_filter)
            .setItems(filters, (dialog, which) -> {
                if (currentPosition < pageList.size()) {
                    DocPage page = pageList.get(currentPosition);
                    page.setFilterType(which);
                    loadCurrentPage();
                }
            })
            .show();
    }

    private void confirmDeletePage() {
        if (pageList.size() <= 1) {
            Toast.makeText(this, "A document must contain at least one page.", Toast.LENGTH_SHORT).show();
            return;
        }

        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_confirm_delete, null);
        AlertDialog dialog = new AlertDialog.Builder(this)
            .setView(dialogView)
            .create();

        TextView title = dialogView.findViewById(R.id.dialog_title);
        TextView message = dialogView.findViewById(R.id.dialog_message);
        Button btnCancel = dialogView.findViewById(R.id.btn_confirm_cancel);
        Button btnConfirm = dialogView.findViewById(R.id.btn_confirm_action);

        title.setText(R.string.dialog_delete_page_title);
        message.setText(getString(R.string.dialog_delete_page_msg, currentPosition + 1));
        btnConfirm.setText(R.string.action_delete);

        btnCancel.setOnClickListener(v -> dialog.dismiss());
        btnConfirm.setOnClickListener(v -> {
            dialog.dismiss();
            pageList.remove(currentPosition);
            if (currentPosition >= pageList.size()) {
                currentPosition = pageList.size() - 1;
            }
            thumbAdapter.setPages(pageList, currentPosition);
            loadCurrentPage();
        });
        dialog.show();
    }

    private void loadCurrentPage() {
        if (currentPosition < 0 || currentPosition >= pageList.size()) return;
        DocPage page = pageList.get(currentPosition);
        textPageTitle.setText(getString(R.string.viewer_page_indicator, currentPosition + 1, pageList.size()));

        progress.setVisibility(View.VISIBLE);
        executor.execute(() -> {
            Bitmap raw = ImageEngine.decodeSampledBitmapFromFile(page.getImagePath(), 1600, 1600);
            if (raw != null) {
                final Bitmap processed = ImageEngine.applyPageAdjustments(raw, page);
                mainHandler.post(() -> {
                    progress.setVisibility(View.GONE);
                    imagePreview.setImageBitmap(processed);
                });
            } else {
                mainHandler.post(() -> progress.setVisibility(View.GONE));
            }
        });
    }

    private void showExportDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_pdf_export_options, null);
        AlertDialog dialog = new AlertDialog.Builder(this)
            .setView(dialogView)
            .create();

        EditText editFilename = dialogView.findViewById(R.id.edit_export_filename);
        Spinner spinPageSize = dialogView.findViewById(R.id.spinner_page_size);
        Spinner spinQuality = dialogView.findViewById(R.id.spinner_quality);
        Button btnCancel = dialogView.findViewById(R.id.btn_dialog_cancel);
        Button btnCreate = dialogView.findViewById(R.id.btn_dialog_create_pdf);

        String defaultName = "DocFlow_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        editFilename.setText(defaultName);

        String[] sizes = {PdfEngine.PAGE_SIZE_A4, PdfEngine.PAGE_SIZE_LETTER, PdfEngine.PAGE_SIZE_LEGAL, PdfEngine.PAGE_SIZE_FIT};
        spinPageSize.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, sizes));

        String[] qualities = {"High Quality", "Medium Quality", "Low (Smallest Size)"};
        spinQuality.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, qualities));

        btnCancel.setOnClickListener(v -> dialog.dismiss());
        btnCreate.setOnClickListener(v -> {
            String filename = editFilename.getText().toString().trim();
            if (filename.isEmpty()) filename = defaultName;
            if (!filename.endsWith(".pdf")) filename += ".pdf";

            String selectedSize = sizes[spinPageSize.getSelectedItemPosition()];
            int quality = 85;
            if (spinQuality.getSelectedItemPosition() == 0) quality = 95;
            else if (spinQuality.getSelectedItemPosition() == 2) quality = 60;

            dialog.dismiss();
            generatePdfAndFinish(filename, selectedSize, quality);
        });

        dialog.show();
    }

    private void generatePdfAndFinish(String filename, String pageSize, int quality) {
        progress.setVisibility(View.VISIBLE);
        btnSavePdf.setEnabled(false);

        executor.execute(() -> {
            File docsDir = new File(getFilesDir(), "documents");
            if (!docsDir.exists()) docsDir.mkdirs();

            File pdfFile = new File(docsDir, filename);
            boolean ok = PdfEngine.createPdfFromPages(this, pageList, pdfFile, pageSize, PdfEngine.ORIENTATION_AUTO, quality);

            if (ok) {
                String docId = String.valueOf(System.currentTimeMillis());
                File thumb = PdfEngine.generatePdfThumbnail(this, pdfFile, docId);

                DocModel doc = new DocModel();
                doc.setId(docId);
                doc.setTitle(filename.replace(".pdf", ""));
                doc.setPdfPath(pdfFile.getAbsolutePath());
                if (thumb != null) doc.setThumbnailPath(thumb.getAbsolutePath());
                doc.setDateModified(System.currentTimeMillis());
                doc.setPageCount(pageList.size());
                doc.setFileSizeBytes(pdfFile.length());
                doc.setTag("scans");

                DocRepository.getInstance(this).addDocument(doc);

                mainHandler.post(() -> {
                    progress.setVisibility(View.GONE);
                    Toast.makeText(this, R.string.msg_saved, Toast.LENGTH_SHORT).show();

                    Intent viewerIntent = new Intent(this, PdfViewerActivity.class);
                    viewerIntent.putExtra("doc_model", doc);
                    startActivity(viewerIntent);
                    finish();
                });
            } else {
                mainHandler.post(() -> {
                    progress.setVisibility(View.GONE);
                    btnSavePdf.setEnabled(true);
                    Toast.makeText(this, R.string.msg_operation_failed, Toast.LENGTH_SHORT).show();
                });
            }
        });
    }
}
