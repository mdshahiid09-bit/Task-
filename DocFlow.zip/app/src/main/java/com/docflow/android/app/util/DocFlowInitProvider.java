package com.docflow.android.app.util;

import android.app.Activity;
import android.app.Application;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import com.docflow.android.app.SplashActivity;
import com.docflow.android.app.data.DocRepository;
import java.io.File;

public class DocFlowInitProvider extends ContentProvider {

    @Override
    public boolean onCreate() {
        Context context = getContext();
        if (context == null) return false;

        Context appContext = context.getApplicationContext();

        // 1. Initialize and apply user theme
        ThemeManager.applyTheme(appContext);

        // 2. Initialize repository and ensure local directories exist
        DocRepository.getInstance(appContext);

        File docDir = new File(appContext.getFilesDir(), "documents");
        if (!docDir.exists()) docDir.mkdirs();

        File thumbDir = new File(appContext.getFilesDir(), "thumbnails");
        if (!thumbDir.exists()) thumbDir.mkdirs();

        File cacheScanDir = new File(appContext.getCacheDir(), "scans");
        if (!cacheScanDir.exists()) cacheScanDir.mkdirs();

        // 3. Register ActivityLifecycleCallbacks to route from blank MainActivity to SplashActivity
        if (appContext instanceof Application) {
            ((Application) appContext).registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                @Override
                public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
                    if (activity.getClass().getName().endsWith(".MainActivity")) {
                        Intent intent = new Intent(activity, SplashActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        activity.startActivity(intent);
                        activity.finish();
                    }
                }

                @Override public void onActivityStarted(Activity activity) {}
                @Override public void onActivityResumed(Activity activity) {}
                @Override public void onActivityPaused(Activity activity) {}
                @Override public void onActivityStopped(Activity activity) {}
                @Override public void onActivitySaveInstanceState(Activity activity, Bundle outState) {}
                @Override public void onActivityDestroyed(Activity activity) {}
            });
        }
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        return null;
    }

    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }
}
