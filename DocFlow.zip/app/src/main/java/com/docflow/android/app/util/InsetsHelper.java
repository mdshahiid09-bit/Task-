package com.docflow.android.app.util;

import android.app.Activity;
import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

public class InsetsHelper {

    /**
     * Configures modern edge-to-edge layout, hiding status bar while correctly
     * handling system gesture insets and navigation bars so controls are not obscured.
     */
    public static void setupEdgeToEdge(Activity activity, View contentView) {
        if (activity == null || activity.getWindow() == null) return;
        Window window = activity.getWindow();

        // Allow layout behind system bars
        WindowCompat.setDecorFitsSystemWindows(window, false);

        // Hide status bar using WindowInsetsControllerCompat
        WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(window, window.getDecorView());
        if (controller != null) {
            controller.hide(WindowInsetsCompat.Type.statusBars());
            controller.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        }

        // Apply insets padding to content view to prevent navigation bar overlap
        if (contentView != null) {
            ViewCompat.setOnApplyWindowInsetsListener(contentView, (v, windowInsets) -> {
                Insets insets = windowInsets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout()
                );
                v.setPadding(insets.left, 0, insets.right, insets.bottom);
                return windowInsets;
            });
        }
    }

    /**
     * Hides both status bar and navigation bar for completely immersive full screen
     * (used in Document Scanner and PDF Reader).
     */
    public static void setupImmersiveFullscreen(Activity activity, View contentView) {
        if (activity == null || activity.getWindow() == null) return;
        Window window = activity.getWindow();

        WindowCompat.setDecorFitsSystemWindows(window, false);

        WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(window, window.getDecorView());
        if (controller != null) {
            controller.hide(WindowInsetsCompat.Type.statusBars() | WindowInsetsCompat.Type.navigationBars());
            controller.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        }

        if (contentView != null) {
            ViewCompat.setOnApplyWindowInsetsListener(contentView, (v, windowInsets) -> {
                Insets insets = windowInsets.getInsets(WindowInsetsCompat.Type.displayCutout());
                v.setPadding(insets.left, insets.top, insets.right, insets.bottom);
                return windowInsets;
            });
        }
    }
}
