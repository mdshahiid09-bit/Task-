package com.docflow.android.app.engine;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import com.docflow.android.app.model.DocPage;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class PdfEngine {

    public static final String PAGE_SIZE_A4 = "A4";
    public static final String PAGE_SIZE_LETTER = "Letter";
    public static final String PAGE_SIZE_LEGAL = "Legal";
    public static final String PAGE_SIZE_FIT = "Fit";

    public static final String ORIENTATION_PORTRAIT = "Portrait";
    public static final String ORIENTATION_LANDSCAPE = "Landscape";
    public static final String ORIENTATION_AUTO = "Auto";

    /**
     * Converts a list of DocPages into a PDF file using Android's native PdfDocument.
     */
    public static boolean createPdfFromPages(Context context, List<DocPage> pages, File outputFile,
                                             String pageSize, String orientation, int quality) {
        if (pages == null || pages.isEmpty() || outputFile == null) return false;

        PdfDocument document = new PdfDocument();
        try {
            for (int i = 0; i < pages.size(); i++) {
                DocPage page = pages.get(i);
                Bitmap raw = ImageEngine.decodeSampledBitmapFromFile(page.getImagePath(), 2048, 2048);
                if (raw == null) continue;

                Bitmap processed = ImageEngine.applyPageAdjustments(raw, page);

                int pageTargetWidth;
                int pageTargetHeight;

                if (PAGE_SIZE_FIT.equalsIgnoreCase(pageSize)) {
                    pageTargetWidth = processed.getWidth();
                    pageTargetHeight = processed.getHeight();
                } else {
                    int standardW = 595; // A4 standard width in points
                    int standardH = 842; // A4 standard height in points
                    if (PAGE_SIZE_LETTER.equalsIgnoreCase(pageSize)) {
                        standardW = 612;
                        standardH = 792;
                    } else if (PAGE_SIZE_LEGAL.equalsIgnoreCase(pageSize)) {
                        standardW = 612;
                        standardH = 1008;
                    }

                    boolean isLandscape = false;
                    if (ORIENTATION_LANDSCAPE.equalsIgnoreCase(orientation)) {
                        isLandscape = true;
                    } else if (ORIENTATION_AUTO.equalsIgnoreCase(orientation)) {
                        isLandscape = processed.getWidth() > processed.getHeight();
                    }

                    if (isLandscape) {
                        pageTargetWidth = Math.max(standardW, standardH);
                        pageTargetHeight = Math.min(standardW, standardH);
                    } else {
                        pageTargetWidth = Math.min(standardW, standardH);
                        pageTargetHeight = Math.max(standardW, standardH);
                    }
                }

                PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(
                    pageTargetWidth, pageTargetHeight, i + 1
                ).create();

                PdfDocument.Page pdfPage = document.startPage(pageInfo);
                Canvas canvas = pdfPage.getCanvas();
                canvas.drawColor(Color.WHITE);

                // Fit and center image within page bounds
                RectF destRect = calculateFittedRect(
                    processed.getWidth(), processed.getHeight(),
                    pageTargetWidth, pageTargetHeight
                );

                Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
                canvas.drawBitmap(processed, null, destRect, paint);

                document.finishPage(pdfPage);

                if (processed != raw && !processed.isRecycled()) {
                    processed.recycle();
                }
                if (!raw.isRecycled()) {
                    raw.recycle();
                }
            }

            File parent = outputFile.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();

            try (FileOutputStream fos = new FileOutputStream(outputFile)) {
                document.writeTo(fos);
                fos.flush();
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            document.close();
        }
    }

    private static RectF calculateFittedRect(int imgW, int imgH, int pageW, int pageH) {
        float scale = Math.min((float) pageW / imgW, (float) pageH / imgH);
        float scaledW = imgW * scale;
        float scaledH = imgH * scale;
        float left = (pageW - scaledW) / 2.0f;
        float top = (pageH - scaledH) / 2.0f;
        return new RectF(left, top, left + scaledW, top + scaledH);
    }

    public static int getPdfPageCount(File pdfFile) {
        if (pdfFile == null || !pdfFile.exists()) return 0;
        try (ParcelFileDescriptor pfd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY);
             PdfRenderer renderer = new PdfRenderer(pfd)) {
            return renderer.getPageCount();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public static Bitmap renderPdfPageToBitmap(File pdfFile, int pageIndex, int targetWidth) {
        if (pdfFile == null || !pdfFile.exists() || pageIndex < 0) return null;
        try (ParcelFileDescriptor pfd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY);
             PdfRenderer renderer = new PdfRenderer(pfd)) {
            if (pageIndex >= renderer.getPageCount()) return null;

            try (PdfRenderer.Page page = renderer.openPage(pageIndex)) {
                int w = page.getWidth();
                int h = page.getHeight();
                float scale = (float) targetWidth / w;
                int renderW = targetWidth;
                int renderH = Math.round(h * scale);

                Bitmap bitmap = Bitmap.createBitmap(renderW, renderH, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(bitmap);
                canvas.drawColor(Color.WHITE);

                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                return bitmap;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static File generatePdfThumbnail(Context context, File pdfFile, String docId) {
        Bitmap thumb = renderPdfPageToBitmap(pdfFile, 0, 360);
        if (thumb == null) return null;

        File thumbsDir = new File(context.getFilesDir(), "thumbnails");
        if (!thumbsDir.exists()) thumbsDir.mkdirs();
        File thumbFile = new File(thumbsDir, "thumb_" + docId + ".jpg");

        boolean ok = ImageEngine.saveBitmapToFile(thumb, thumbFile, Bitmap.CompressFormat.JPEG, 85);
        thumb.recycle();
        return ok ? thumbFile : null;
    }

    /**
     * Merges multiple PDF files into one output PDF.
     */
    public static boolean mergePdfs(List<File> sourcePdfs, File outputFile) {
        if (sourcePdfs == null || sourcePdfs.isEmpty() || outputFile == null) return false;
        PdfDocument document = new PdfDocument();
        int totalOutputPage = 1;

        try {
            for (File pdf : sourcePdfs) {
                if (pdf == null || !pdf.exists()) continue;
                try (ParcelFileDescriptor pfd = ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY);
                     PdfRenderer renderer = new PdfRenderer(pfd)) {

                    for (int i = 0; i < renderer.getPageCount(); i++) {
                        try (PdfRenderer.Page page = renderer.openPage(i)) {
                            int w = page.getWidth();
                            int h = page.getHeight();

                            PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(w, h, totalOutputPage).create();
                            PdfDocument.Page newPage = document.startPage(pageInfo);

                            Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT);

                            Canvas canvas = newPage.getCanvas();
                            canvas.drawColor(Color.WHITE);
                            canvas.drawBitmap(bitmap, 0, 0, null);

                            document.finishPage(newPage);
                            bitmap.recycle();
                            totalOutputPage++;
                        }
                    }
                }
            }

            File parent = outputFile.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();

            try (FileOutputStream fos = new FileOutputStream(outputFile)) {
                document.writeTo(fos);
                fos.flush();
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            document.close();
        }
    }

    /**
     * Splits PDF into single-page documents in outputDir.
     */
    public static List<File> splitPdf(File sourcePdf, File outputDir) {
        List<File> result = new ArrayList<>();
        if (sourcePdf == null || !sourcePdf.exists() || outputDir == null) return result;
        if (!outputDir.exists()) outputDir.mkdirs();

        String baseName = sourcePdf.getName().replace(".pdf", "");

        try (ParcelFileDescriptor pfd = ParcelFileDescriptor.open(sourcePdf, ParcelFileDescriptor.MODE_READ_ONLY);
             PdfRenderer renderer = new PdfRenderer(pfd)) {

            for (int i = 0; i < renderer.getPageCount(); i++) {
                PdfDocument singleDoc = new PdfDocument();
                try (PdfRenderer.Page page = renderer.openPage(i)) {
                    int w = page.getWidth();
                    int h = page.getHeight();

                    PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(w, h, 1).create();
                    PdfDocument.Page newPage = singleDoc.startPage(pageInfo);

                    Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT);

                    Canvas canvas = newPage.getCanvas();
                    canvas.drawColor(Color.WHITE);
                    canvas.drawBitmap(bitmap, 0, 0, null);

                    singleDoc.finishPage(newPage);
                    bitmap.recycle();

                    File outPageFile = new File(outputDir, baseName + "_page_" + (i + 1) + ".pdf");
                    try (FileOutputStream fos = new FileOutputStream(outPageFile)) {
                        singleDoc.writeTo(fos);
                        fos.flush();
                        result.add(outPageFile);
                    }
                } finally {
                    singleDoc.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * Extracts specific 1-based page numbers from sourcePdf into outputFile.
     */
    public static boolean extractPages(File sourcePdf, List<Integer> pageNumbers, File outputFile) {
        if (sourcePdf == null || !sourcePdf.exists() || pageNumbers == null || pageNumbers.isEmpty() || outputFile == null) {
            return false;
        }
        PdfDocument document = new PdfDocument();

        try (ParcelFileDescriptor pfd = ParcelFileDescriptor.open(sourcePdf, ParcelFileDescriptor.MODE_READ_ONLY);
             PdfRenderer renderer = new PdfRenderer(pfd)) {

            int outPageIndex = 1;
            for (int pageNum : pageNumbers) {
                int zeroIndex = pageNum - 1;
                if (zeroIndex < 0 || zeroIndex >= renderer.getPageCount()) continue;

                try (PdfRenderer.Page page = renderer.openPage(zeroIndex)) {
                    int w = page.getWidth();
                    int h = page.getHeight();

                    PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(w, h, outPageIndex).create();
                    PdfDocument.Page newPage = document.startPage(pageInfo);

                    Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT);

                    Canvas canvas = newPage.getCanvas();
                    canvas.drawColor(Color.WHITE);
                    canvas.drawBitmap(bitmap, 0, 0, null);

                    document.finishPage(newPage);
                    bitmap.recycle();
                    outPageIndex++;
                }
            }

            File parent = outputFile.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();

            try (FileOutputStream fos = new FileOutputStream(outputFile)) {
                document.writeTo(fos);
                fos.flush();
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            document.close();
        }
    }

    /**
     * Exports all pages of a PDF as individual image files.
     */
    public static List<File> exportPagesToImages(File sourcePdf, File outputDir, String format) {
        List<File> images = new ArrayList<>();
        if (sourcePdf == null || !sourcePdf.exists() || outputDir == null) return images;
        if (!outputDir.exists()) outputDir.mkdirs();

        String baseName = sourcePdf.getName().replace(".pdf", "");
        boolean isPng = "PNG".equalsIgnoreCase(format);
        Bitmap.CompressFormat compFormat = isPng ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG;
        String ext = isPng ? ".png" : ".jpg";

        try (ParcelFileDescriptor pfd = ParcelFileDescriptor.open(sourcePdf, ParcelFileDescriptor.MODE_READ_ONLY);
             PdfRenderer renderer = new PdfRenderer(pfd)) {

            for (int i = 0; i < renderer.getPageCount(); i++) {
                try (PdfRenderer.Page page = renderer.openPage(i)) {
                    int w = page.getWidth() * 2; // 2x DPI for high clarity export
                    int h = page.getHeight() * 2;

                    Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT);

                    File imgFile = new File(outputDir, baseName + "_page_" + (i + 1) + ext);
                    ImageEngine.saveBitmapToFile(bitmap, imgFile, compFormat, 90);
                    bitmap.recycle();
                    images.add(imgFile);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return images;
    }

    /**
     * Compresses PDF by re-sampling raster bitmaps at a balanced compression quality.
     * Returns true if successfully generated with measurable reduction.
     */
    public static boolean compressPdf(File sourcePdf, File outputFile, int qualityPercent) {
        if (sourcePdf == null || !sourcePdf.exists() || outputFile == null) return false;
        PdfDocument document = new PdfDocument();

        try (ParcelFileDescriptor pfd = ParcelFileDescriptor.open(sourcePdf, ParcelFileDescriptor.MODE_READ_ONLY);
             PdfRenderer renderer = new PdfRenderer(pfd)) {

            for (int i = 0; i < renderer.getPageCount(); i++) {
                try (PdfRenderer.Page page = renderer.openPage(i)) {
                    int w = page.getWidth();
                    int h = page.getHeight();

                    // Render page bitmap
                    Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT);

                    // Compress to JPEG byte stream at qualityPercent
                    java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, qualityPercent, baos);
                    byte[] compressedBytes = baos.toByteArray();
                    bitmap.recycle();

                    // Decode compressed JPEG back to draw into new PDF page
                    Bitmap compBitmap = android.graphics.BitmapFactory.decodeByteArray(compressedBytes, 0, compressedBytes.length);

                    PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(w, h, i + 1).create();
                    PdfDocument.Page newPage = document.startPage(pageInfo);

                    Canvas canvas = newPage.getCanvas();
                    canvas.drawColor(Color.WHITE);
                    canvas.drawBitmap(compBitmap, 0, 0, null);

                    document.finishPage(newPage);
                    compBitmap.recycle();
                }
            }

            File parent = outputFile.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();

            try (FileOutputStream fos = new FileOutputStream(outputFile)) {
                document.writeTo(fos);
                fos.flush();
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            document.close();
        }
    }
}
